        org $0b00
        ldx #$2700
        jsr $5585

harness_done
        bra harness_done
