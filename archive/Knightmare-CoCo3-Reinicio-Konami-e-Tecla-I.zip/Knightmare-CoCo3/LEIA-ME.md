# Knightmare CoCo 3 — reinício KONAMI e tecla I

**Revisão 31/10/2026 — reinício corrigido e invencibilidade de teste.** Ao acabarem as vidas, o jogo volta automaticamente à abertura azul da KONAMI e depois ao título. Espaço permite iniciar uma nova partida. Durante o jogo, **I liga/desliga a proteção de teste**; a borda fica azul quando ela está ligada. Uma nova partida começa com essa proteção desligada.

Detalhes e evidência: [REINICIO-E-TECLA-I.md](analysis/REINICIO-E-TECLA-I.md). Confira `VERSAO.txt` na pasta extraída para identificar este pacote.

Esta revisão integra ao jogo as rotinas 6809 traduzidas da IA da ROM: inimigos da primeira fase, ondas/formações, disparos e primeiro chefe com seus três satélites. Também reconstrói o trecho correto após perder uma vida. As versões DAC6 e Orchestra-90 CC usam **128 KiB, sem música e com efeitos sonoros**. A abertura KONAMI mantém o fundo azul corrigido.

**A campanha jogável continua limitada à primeira fase.** As demais fases têm recursos/tabelas extraídos e um visualizador separado; seus inimigos e chefes ainda precisam de tradução e integração. Esta entrega não representa equivalência completa de gráficos, som ou desempenho com o MSX.

## Executar

Extraia este pacote em uma pasta nova e execute `EXECUTAR-DAC6.cmd` ou `EXECUTAR-ORCH90.cmd`. Aguarde o Disk BASIC carregar os recursos. Espaço pula a animação KONAMI e, no título, inicia a partida. Os scripts procuram o XRoar existente neste computador.

Para indicar outra instalação:

```powershell
python tools/run_demo.py --variant DAC6 --xroar C:\caminho\xroar.exe
python tools/run_demo.py --variant ORCH90 --xroar C:\caminho\xroar.exe
```

Ou monte `bin/DAC6.DSK` / `bin/ORCH90.DSK` no drive 0 e digite `RUN"START"`. Use CoCo 3 de 128 KiB, RGB e as ROMs de sistema `coco3.rom`/`disk11.rom` do usuário ao lado do emulador. Orchestra usa Multi-Pak, cartucho no slot 0 e disco no slot 3, com slot 3 selecionado. As ROMs de sistema não são incluídas.

| Controle | Ação |
| --- | --- |
| Setas ou W/A/S/D | Mover, incluindo diagonais |
| Espaço / botão do joystick selecionado | Pular abertura, iniciar ou disparar |
| K | Teclado |
| J / L | Joystick analógico direito / esquerdo, mantendo teclado |
| I | Ligar/desligar invencibilidade de teste; borda azul indica proteção ativa |
| P | Pausar/retomar |
| R | Nova partida na primeira fase; também pula a abertura |

## O que mudou

- Curvas, velocidades fracionárias, estados e arrancadas dos inimigos vêm das rotinas originais.
- Duas filas de ondas, grupos/formações, intervalos, condições de tiro e famílias de projéteis foram portados.
- O primeiro chefe passa a escolher destinos, esperar e atacar segundo a ROM. Os satélites seguem sua trajetória original.
- Perder uma vida retorna ao início do trecho de 192 pixels, reconstrói objetos/inimigos e rebobina as ondas. Armas, velocidade e habilidades são removidas, como no MSX.
- No trecho final, o estado do chefe e os contadores/frações dos satélites são preservados.
- A rolagem segue o ritmo original: aproximadamente 7,49 pixels/s. O valor anterior era o dobro. Ainda pode haver lentidão de processamento com muitos objetos.

Armas, tokens, escudo, invisibilidade, invencibilidade, blocos ocultos, bomba, congelamento, ponte e passagens continuam disponíveis conforme os dados já integrados. Ponte/bloco cinzento são implementados, mas não aparecem naturalmente na primeira fase. Depois de derrotar o chefe, esta versão encerra a fase; ainda não segue para a segunda. EXIT continua limitado à demonstração da primeira fase.

## Evidência e limites

As duas variantes passaram nos testes em XRoar de 128 KiB: 5.400 amostras de trajetórias por variante contra instruções Z80 executadas, 640 quadros do chefe/satélites, 91 nascimentos em 6.000 atualizações, 56 cenários de disparo, dez retornos de trecho e os 34 rebobinamentos de ondas. Também passaram as regressões de controles, combate, itens e áudio.

O teste integrado percorreu a fase inteira e derrotou o chefe com flechas nativas, usando a proteção ativada pela tecla I e suprimindo tokens. Isso não é uma partida sem intervenção. Não houve teste em CoCo físico.

- [REINICIO-E-TECLA-I.md](analysis/REINICIO-E-TECLA-I.md): correção do fim das vidas e tecla I.
- [IA-E-CHECKPOINTS.md](analysis/IA-E-CHECKPOINTS.md): regras, endereços, método, memória, desempenho e limitações.
- `analysis/ai-rom-reference.json`: tabelas e resultados obtidos executando a ROM Z80.
- `analysis/*-ai-verification.json`, `*-checkpoints-verification.json`, `*-stage1-flow-verification.json`: evidência vinculada aos discos testados.
- `src/ai.asm`, `boss_ai.asm`, `checkpoints.asm`, `ai_data.inc`: código 6809 e dados reutilizáveis.
- `STATUS.json`: escopo implementado e trabalho restante.

O código fixo está próximo do limite da janela de memória. A próxima etapa das outras fases exige reorganizar/carregar rotinas e gráficos por bancos. O visualizador `VISUALIZAR-8-MAPAS.cmd` permanece separado do jogo principal; seu carregador não faz ainda a progressão da campanha.

## Compilar

Os recursos prontos estão incluídos. Com Python e LWASM:

```powershell
python tools/build.py --lwasm C:\caminho\lwasm.exe
```

Para regenerar a partir da ROM e repetir as comparações, siga [IA-E-CHECKPOINTS.md](analysis/IA-E-CHECKPOINTS.md). O fonte entregue foi regenerado e recompilado, reproduzindo byte a byte os discos testados. O histórico REA/Ghidra e as licenças das ferramentas permanecem no pacote. Relatórios anteriores estão marcados como históricos e não descrevem o comportamento atual dos checkpoints.
