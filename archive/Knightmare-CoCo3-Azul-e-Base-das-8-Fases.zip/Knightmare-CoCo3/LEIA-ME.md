<!-- BLUE-CAMPAIGN-REVISION -->
# Knightmare CoCo 3 — abertura azul e base das oito fases

**A abertura KONAMI agora tem fundo azul**, conforme a ROM MSX. O título e o jogo voltam ao fundo preto. A correção está nas duas variantes de 128 KiB, DAC6 e Orchestra-90 CC, mantendo efeitos sonoros e sem música.

**As sete fases restantes ainda não estão convertidas em fases jogáveis.** Esta revisão acrescenta um carregador 6809 e um visualizador separados, com mapas, tiles e scripts extraídos das oito fases. Inimigos, chefes posteriores e transições ainda precisam ser integrados ao motor.

- Para jogar a primeira fase atualizada: `EXECUTAR-DAC6.cmd` ou `EXECUTAR-ORCH90.cmd`.
- Para inspecionar os oito mapas: `VISUALIZAR-8-MAPAS.cmd`; cima/baixo percorrem oito pixels por toque e Espaço passa à próxima fase. O visualizador não tem combate.
- Análise, parâmetros originais e limites: [FASES-2-A-8.md](analysis/FASES-2-A-8.md).
- Fonte do novo carregador/renderizador: `campaign/src/stage_loader.asm`.
- Evidência do carregamento e das 24 imagens comparadas: `campaign/analysis/loader-verification.json`.

O jogo passou novamente nas regressões de abertura/itens, combate e controles/rolagem nas duas variantes. O visualizador foi executado e comparado em 128 KiB. A validação não demonstra uma campanha completa nem equivalência de IA com o MSX.

<!-- BLUE-CAMPAIGN-REVISION -->

# Knightmare CoCo 3 — introdução e itens

Abertura animada com o logotipo **KONAMI**, tela de título original, tokens de armas/habilidades e objetos fixos integrados ao motor 6809. As duas variantes continuam usando **128 KiB**, sem música de fundo, com efeitos por evento no DAC6 ou Orchestra-90 CC.

**A integração jogável ainda cobre a primeira fase e seu chefe.** As tabelas de itens das oito fases foram extraídas para análise, mas as fases seguintes não estão jogáveis. EXIT encerra esta demonstração quando habilitado; ainda não carrega os destinos originais. Não é uma conversão completa nem equivalência exata ao MSX: a IA dos inimigos e partes da progressão continuam adaptadas.

## Executar

Feche o XRoar antigo, extraia o pacote novo e execute `EXECUTAR-DAC6.cmd` ou `EXECUTAR-ORCH90.cmd`. Aguarde o carregamento e a animação KONAMI. Espaço pula a animação; na tela de título, Espaço inicia a partida.

Os scripts procuram o XRoar instalado neste computador. Para outra instalação:

```powershell
python tools/run_demo.py --variant DAC6 --xroar C:\caminho\xroar.exe
python tools/run_demo.py --variant ORCH90 --xroar C:\caminho\xroar.exe
```

Ou monte `bin/DAC6.DSK` / `bin/ORCH90.DSK` no drive 0 e digite `RUN"START"`. As ROMs de sistema do usuário `coco3.rom` e `disk11.rom` devem estar ao lado do emulador; não são incluídas. Use RGB. Orchestra configura Multi-Pak: cartucho no slot 0 e disco no slot 3, selecionando o slot 3.

| Controle | Ação |
| --- | --- |
| Espaço / botão do joystick selecionado | Pular abertura, iniciar ou disparar |
| Setas ou W/A/S/D | Mover; diagonais permitidas |
| K | Somente teclado, modo inicial |
| J / L | Joystick analógico direito / esquerdo, mantendo teclado |
| P | Pausar/retomar durante a fase |
| R | Reiniciar a fase; na abertura, iniciar diretamente |

## Armas e habilidades

Atire no token flutuante para mudar sua recompensa e encoste nele para coletar. Cada fase tem sua sequência de aparição; não foram acrescentados sorteios de drops. A posição horizontal inicial segue Popolon, com os limites da ROM.

| Recompensa | Comportamento |
| --- | --- |
| Arma | Seleciona uma das famílias da tabela original; repetir a mesma família ativa sua forma seguinte |
| Tiro triplo | Três direções simultâneas; exige os três espaços de projéteis livres |
| Bumerangue | Segue a rampa original e retorna; acompanha a posição horizontal do jogador |
| Velocidade | Sobe até o nível 4, usando as frações de movimento extraídas da ROM |
| Escudo | Proteção frontal com 30 unidades; projéteis dos tipos rápidos consomem quatro unidades |
| Invisibilidade | Cerca de 15 s sem dano de inimigos/projéteis, com a arte original e aviso visual ao acabar |
| Invencibilidade | Cerca de 15 s; acelera, elimina inimigos por contato e desativa disparos, conforme o original |
| Token sem prêmio | Soma 1.000 pontos; os tokens úteis somam 200 |

Se ainda houver cargas de escudo, ele volta quando termina uma habilidade temporária. O inventário permanece ao renascer nesta versão; a restauração completa dos checkpoints MSX ainda não foi convertida.

Os blocos do cenário também seguem a lista original: alguns já mostram `?`; outros só aparecem ao receber um tiro. Rompê-los libera vidas, 500 pontos, bomba ou congelamento. O congelamento para a rolagem e os inimigos por aproximadamente 10 s. As passagens laterais exigem pressionar a direção do respectivo bordo.

Bloco cinzento e ponte também têm desenho e colisão implementados, mas **não existem na lista original da primeira fase**. Foram verificados em cenários preparados pelo depurador, sem acrescentá-los artificialmente à fase. EXIT respeita a habilitação por conclusão de fase, preservada ao reiniciar a sessão, mas nesta demonstração apenas encerra a fase.

## Arquivos e análise

- `src/intro.asm`: sequência KONAMI e título; pixels extraídos da ROM.
- `src/items.asm`, `items_state.inc`, `items_data.inc`: tokens, habilidades, objetos e tabelas.
- `src/weapons.asm`: formas de armas, tiro triplo, bumerangue e escudo.
- `src/gameplay.asm`, `combat.asm`: ação, cenário, composição e colisões.
- `src/audio_sfx.asm`: efeitos por evento; música desativada.
- `analysis/ITENS-E-INTRO.md`: endereços originais, regras confirmadas e adaptações.
- `analysis/items-assets.json`: tabelas das oito fases e recursos usados.
- `analysis/*-items-verification.json`: resultados da abertura, inventário e objetos em 128 KiB.
- `analysis/*-combat-verification.json`, `*-controls-verification.json`: regressões de combate/entrada/rolagem.
- `analysis/performance-items.json`: custo medido desta versão, sem promessa de FPS constante.

Os efeitos novos de troca e coleta vêm dos IDs originais `$0E` e `$12`, capturados isoladamente no openMSX e convertidos para PCM. A reprodução é aproximada, de uma voz por vez. Jingles musicais de aquisição continuam omitidos para respeitar a opção sem música; usa-se o efeito curto de coleta. Os demais sons mantêm as limitações documentadas nas etapas anteriores.

## Compilar e verificar

Python 3, LWASM e XRoar existentes; sem pacotes Python extras:

```powershell
python tools/prepare_combat.py --rom C:\caminho\Knightmare.rom
python tools/prepare_items.py --rom C:\caminho\Knightmare.rom
python tools/prepare_sfx.py
python tools/build.py --lwasm C:\caminho\lwasm.exe
python tools/verify_items.py --xroar C:\caminho\xroar.exe
python tools/verify_combat.py --xroar C:\caminho\xroar.exe
python tools/verify_controls_scroll.py --xroar C:\caminho\xroar.exe
```

Os recursos já estão incluídos para recompilar; a ROM só é necessária para regenerá-los. O verificador testa a aparição natural do primeiro token e usa posições/colisões preparadas para cobrir as demais regras. Também compara imagens com um renderizador independente. Não substitui uma partida completa sem intervenção ou teste em CoCo físico/joystick real.

A ROM do usuário foi preservada, SHA-256 `589b2fd276d84827bb1b033f43a0cd5ab0aa9da3c8784cac2f62474fed00aae3`. O histórico REA/Ghidra e as origens das ferramentas de [REA-RETRO-9](https://github.com/benicasa2/REA-RETRO-9) e [antxiko](https://github.com/antxiko/Knightmare-disassembly) permanecem no pacote, com licenças em `third_party/`. Arquivos musicais de referência são históricos de análise e não são carregados pelo jogo.
