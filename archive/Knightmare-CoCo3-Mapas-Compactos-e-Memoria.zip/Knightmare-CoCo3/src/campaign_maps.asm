; Native 6809 translation of MSX $6502..$6586.
; Original shared 4x4 dictionary, MSB-first repetition bits and mirror flag.
; Only the active 244x32 map is expanded in bank 7; all 8 compressed maps
; remain in permanent auxiliary bank 6. Scratch $0d20..$0d34 is init-only.
MAP_LIST equ $0d20
MAP_BITS_END equ $0d22
MAP_CODE equ $0d24
MAP_BITS_PTR equ $0d26
MAP_SEG equ $0d28
MAP_BAND equ $0d29
MAP_BITS equ $0d2a
MAP_GROUP equ $0d2b
MAP_MIRROR equ $0d2c
MAP_ROWS equ $0d2d
MAP_COLS equ $0d2e
MAP_BAND_DEST equ $0d30
MAP_DELTA equ campaign_blob-$99cd

campaign_map_load
        pshs a
        lda $ffa4
        pshs a
        jsr campaign_map_decode
        lda #7
        sta $ffa4
        tst <campaign_stage
        bne campaign_load_done
        include "campaign_map_patch.inc"
campaign_load_done
        puls a
        sta $ffa4
        puls a,pc

; Entry: campaign_stage 0..7. Output: bank 7, CPU $8000..$9e7f.
; Preserves caller registers and FFA4. FIRQ/IRQ never change these windows.
campaign_map_decode
        pshs d,x,y,u
        lda $ffa4
        pshs a
        lda #7
        sta $ffa4
        lda <campaign_stage
        anda #7
        lsla
        lsla
        ldx #campaign_blob
        leax a,x
        jsr campaign_read_pointer
        std MAP_LIST
        leax 2,x
        jsr campaign_read_pointer
        std MAP_BITS_END
        lda #9
        sta MAP_SEG
        ldu #$8000
campaign_segment
        lda MAP_SEG
        lsla
        ldx MAP_LIST
        leax a,x
        jsr campaign_read_pointer
        std MAP_CODE
        lda MAP_SEG
        ldb #6
        mul
        std MAP_BITS_PTR
        ldd MAP_BITS_END
        subd MAP_BITS_PTR
        std MAP_BITS_PTR
        clr MAP_BAND
campaign_band
        stu MAP_BAND_DEST
        ldx MAP_BITS_PTR
        lda ,x+
        stx MAP_BITS_PTR
        sta MAP_BITS
        clr MAP_GROUP
campaign_group
        ldx MAP_CODE
        lda ,x
        sta MAP_MIRROR
        anda #$7f
        ldb #2
        mul
        ldx #campaign_blob+$20
        leax d,x
        jsr campaign_read_pointer
        tfr d,y
        lda #4
        sta MAP_ROWS
        tst MAP_MIRROR
        bmi campaign_mirror_block
campaign_normal_row
        lda #4
        sta MAP_COLS
campaign_normal_pixel
        lda ,y+
        sta ,u+
        dec MAP_COLS
        bne campaign_normal_pixel
        leau 28,u
        dec MAP_ROWS
        bne campaign_normal_row
        leau -124,u
        bra campaign_next_group
campaign_mirror_block
        leau 3,u
campaign_mirror_row
        lda #4
        sta MAP_COLS
campaign_mirror_pixel
        lda ,y+
        bita #$f0
        beq campaign_mirror_store
        cmpa #$a0
        blo campaign_mirror_add
        suba #$60
        bra campaign_mirror_store
campaign_mirror_add
        adda #$60
campaign_mirror_store
        sta ,u
        leau -1,u
        dec MAP_COLS
        bne campaign_mirror_pixel
        leau 36,u
        dec MAP_ROWS
        bne campaign_mirror_row
        leau -127,u
campaign_next_group
        asl MAP_BITS
        bcc campaign_repeat_code
        ldx MAP_CODE
        leax 1,x
        stx MAP_CODE
campaign_repeat_code
        inc MAP_GROUP
        lda MAP_GROUP
        cmpa #8
        lblo campaign_group
        ldu MAP_BAND_DEST
        ; Each segment overlaps its predecessor by one 4-row band.
        tst MAP_BAND
        bne campaign_keep_band
        lda MAP_SEG
        cmpa #9
        bne campaign_discard_band
campaign_keep_band
        leau 128,u
campaign_discard_band
        inc MAP_BAND
        lda MAP_BAND
        cmpa #7
        lblo campaign_band
        dec MAP_SEG
        lbpl campaign_segment
        puls a
        sta $ffa4
        puls d,x,y,u,pc

; Read original little-endian Z80 pointer and relocate it to bank 6.
campaign_read_pointer
        ldb ,x
        lda 1,x
        addd #MAP_DELTA
        rts
