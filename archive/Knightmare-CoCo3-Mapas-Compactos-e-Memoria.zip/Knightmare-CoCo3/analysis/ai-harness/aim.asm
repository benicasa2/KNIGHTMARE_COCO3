        org $0b00
        jsr $57bc
        sta $0be4

harness_done
        bra harness_done
