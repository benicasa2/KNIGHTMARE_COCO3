        org $0b00
        clr $0c40
        jsr $4b3a

harness_done
        bra harness_done
