        org $0b00
        ldx #$2700
        jsr $5759

harness_done
        bra harness_done
