        org $0b00
        orcc #$50
        lda #5
        sta $0c40
        jsr $4bd1

harness_done
        bra harness_done
