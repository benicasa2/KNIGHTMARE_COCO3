        org $0b00
        jsr $5aba

harness_done
        bra harness_done
