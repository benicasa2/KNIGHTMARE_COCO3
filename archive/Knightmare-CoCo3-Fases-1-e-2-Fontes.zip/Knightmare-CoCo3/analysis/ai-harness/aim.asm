        org $0b00
        jsr $5bf6
        sta $0be4

harness_done
        bra harness_done
