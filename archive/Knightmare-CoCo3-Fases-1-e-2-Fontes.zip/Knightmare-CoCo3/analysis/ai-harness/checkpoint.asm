        org $0b00
        jsr $6780

harness_done
        bra harness_done
