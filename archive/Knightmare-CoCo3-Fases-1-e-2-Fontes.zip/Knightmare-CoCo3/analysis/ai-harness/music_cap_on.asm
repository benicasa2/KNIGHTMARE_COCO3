        org $0b00
        lda #1
        sta $0a00
        ldy #$0a00
        jsr $5536

harness_done
        bra harness_done
