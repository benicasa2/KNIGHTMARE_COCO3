        org $0b00
        ldx #$2700
        jsr $5611

harness_done
        bra harness_done
