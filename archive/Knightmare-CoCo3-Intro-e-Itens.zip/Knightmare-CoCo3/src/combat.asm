; First-stage native combat. ROM constants and art are in combat_data.inc.
; Physics/scheduling adaptations are documented in COMBATE.md.
ENTITIES equ $2700
ENTITY_END equ $2960
; Each of 18 slots: active,kind,x8.8,y8.8,vx8.8,vy8.8,hp,age,state,cool,art,...
; 0..6 enemies, 7..9 player arrows, 10..17 hostile shots.
; +17 drawn flag, +18 old physical row, +20 xbyte, +21 width, +22 height.

combat_init
        ldd <high_score
        pshs d
        ldx #ENTITIES
combat_clear_slots
        clr ,x+
        cmpx #ENTITY_END
        blo combat_clear_slots
        ldx #combat_enabled
combat_clear_state
        clr ,x+
        cmpx #combat_frames+2
        blo combat_clear_state
        puls d
        std <high_score
        lda #1
        sta <combat_enabled
        lda #3
        sta <player_lives
        lda #60
        sta <player_invul
        lda #1
        sta <hud_dirty
        rts

; Erase in the reverse order of drawing, preserving overlap backgrounds.
combat_erase
        lda #18
        sta <entity_index
        ldx #ENTITIES+18*32
combat_erase_next
        stx <entity_ptr
        tst 17,x
        beq combat_erase_skip
        ldd 18,x
        std <span_row
        lda 20,x
        sta <span_x
        lda 21,x
        sta <span_n
        lda 22,x
        sta <art_lines
        lda <entity_index
        cmpa #18
        bne combat_erase_standard_buffer
        ldx #$0f00
        bra combat_erase_buffer_ready
combat_erase_standard_buffer
        adda #$11
        clrb
        tfr d,x
combat_erase_buffer_ready
        jsr framebuffer_pointer
combat_erase_line
        jsr write_span_current
        jsr advance_span
        dec <art_lines
        bne combat_erase_line
        ldx <entity_ptr
        clr 17,x
combat_erase_skip
        leax -32,x
        dec <entity_index
        bpl combat_erase_next
        jsr erase_boss
        rts

combat_tick
        ldd <combat_frames
        addd #1
        std <combat_frames
        tst <player_invul
        beq combat_no_invul
        dec <player_invul
combat_no_invul
        tst <combat_status
        lbeq combat_alive
        lda <combat_status
        cmpa #1
        bne combat_tick_return
        dec <death_clock
        bne combat_tick_return
        tst <player_lives
        bne combat_respawn
        lda #2
        sta <combat_status
        lda #$24
        sta $ff9a
        rts
combat_respawn
        clr <combat_status
        lda #120
        sta <player_x
        lda #136
        sta <player_y
        lda #60
        sta <player_invul
        ldx #ENTITIES+10*32
clear_hostile_shots
        clr ,x
        leax 32,x
        cmpx #ENTITY_END
        blo clear_hostile_shots
combat_tick_return
        rts
combat_alive
        jsr fire_player
        jsr move_projectiles
        jsr items_tick
        ldd <freeze_ticks
        bne combat_collisions
        tst <boss_state
        bne combat_boss_active
        ldd <camera_y
        bne combat_waves
        jsr start_boss
        bra combat_boss_active
combat_waves
        jsr spawn_waves
        jsr move_enemies
        bra combat_collisions
combat_boss_active
        jsr update_boss
        jsr move_enemies
combat_collisions
        jsr hit_enemies
        jsr hit_boss
        jsr touch_player
        rts

fire_player
        jmp items_fire_player

move_projectiles
        ldx #ENTITIES+7*32
move_projectile_next
        tst ,x
        beq projectile_skip
        cmpx #ENTITIES+10*32
        bhs projectile_enemy_motion
        jsr weapon_projectile_tick
projectile_enemy_motion
        ldd 4,x
        addd 8,x
        std 4,x
        cmpa #168
        bhs projectile_kill
        ldd 2,x
        addd 6,x
        std 2,x
        cmpa #248
        bhs projectile_kill
        cmpx #ENTITIES+10*32
        blo projectile_skip
        cmpa #8
        blo projectile_kill
        bra projectile_skip
projectile_kill
        clr ,x
projectile_skip
        leax 32,x
        cmpx #ENTITIES+18*32
        blo move_projectile_next
        rts

; Original first-stage wave order/counts, with native wait/formation adaptation.
spawn_waves
        tst <wave_left
        bne spawn_wave_member
        ldd <wave_wait
        beq wave_wait_expired
        subd #1
        std <wave_wait
        rts
wave_wait_expired
        lda <wave_flags
        bita #$20
        bne load_next_wave
        ldx #ENTITIES
wave_wait_enemies
        tst ,x
        bne spawn_wave_return
        leax 32,x
        cmpx #ENTITIES+7*32
        blo wave_wait_enemies
load_next_wave
        lda <wave_index
        lsla
        ldx #original_waves
        leax a,x
        lda ,x+
        sta <wave_flags
        anda #15
        sta <wave_type
        ldb ,x
        tfr b,a
        anda #15
        ldb #16
        mul
        std <wave_wait
        lda ,x
        lsra
        lsra
        lsra
        lsra
        sta <wave_left
        clr <wave_member
        clr <spawn_clock
        inc <wave_index
        lda <wave_index
        cmpa #WAVE_COUNT
        blo wave_loaded
        clr <wave_index
wave_loaded
        lda <wave_flags
        anda #$ff
        beq wave_pause_entry
        tst <wave_left
        bne spawn_wave_member
wave_pause_entry
        clr <wave_left
spawn_wave_return
        rts
spawn_wave_member
        tst <spawn_clock
        beq spawn_member_ready
        dec <spawn_clock
        rts
spawn_member_ready
        ldx #ENTITIES
spawn_find_slot
        tst ,x
        beq spawn_found_slot
        leax 32,x
        cmpx #ENTITIES+7*32
        blo spawn_find_slot
        rts
spawn_found_slot
        lda #1
        sta ,x
        lda <wave_type
        sta 1,x
        sta <temp_index
        lda <wave_member
        anda #7
        ldu #original_spawn_x
        lda a,u
        clrb
        std 2,x
        lda #8
        std 4,x
        ldd #0
        std 6,x
        std 8,x
        clr 11,x
        clr 12,x
        lda #40
        sta 13,x
        lda #1
        sta 10,x
        lda <wave_type
        cmpa #9
        bne spawn_not_nine
        lda #3
        sta 10,x
        ldd #$0200
        bra spawn_velocity_set
spawn_not_nine
        cmpa #14
        bne spawn_bird
        ldd #$0100
        bra spawn_velocity_set
spawn_bird
        cmpa #2
        bne spawn_bird_one
        lda <player_x
        cmpa #128
        blo spawn_two_from_right
        lda #16
        clrb
        std 2,x
        ldd #$0700
        bra spawn_two_vx
spawn_two_from_right
        lda #240
        clrb
        std 2,x
        ldd #-$0700
spawn_two_vx
        std 6,x
        ldd #$0400
        bra spawn_velocity_set
spawn_bird_one
        ldd #$0260
spawn_velocity_set
        std 8,x
        lda <wave_type
        lsla
        ldu #enemy_art_ids
        lda a,u
        sta 14,x
        lda <wave_type
        ldu #original_spawn_gaps
        lda a,u
        lsra
        sta <spawn_clock
        inc <wave_member
        dec <wave_left
        rts

move_enemies
        ldx #ENTITIES
move_enemy_next
        stx <entity_ptr
        lda ,x
        lbeq move_enemy_skip
        cmpa #2
        lbeq enemy_exploding
        lda 1,x
        cmpa #12
        lbeq move_satellite
        inc 11,x
        lda 1,x
        cmpa #1
        bne enemy_not_one
        ; Original type 1 curves toward its launch lane with 8.8 acceleration.
        lda 2,x
        suba #128
        asra
        asra
        asra
        tfr a,b
        sex
        nega
        negb
        sbca #0
        addd 6,x
        std 6,x
enemy_not_one
        lda 1,x
        cmpa #2
        bne enemy_not_two
        ; Reduce side-entry velocity toward the centre as in the original curve.
        ldd 6,x
        asra
        rorb
        asra
        rorb
        std <aim_vx
        ldd 6,x
        subd <aim_vx
        std 6,x
enemy_not_two
        lda 1,x
        cmpa #9
        bne enemy_integrate
        tst 12,x
        bne enemy_nine_dash
        lda <player_y
        suba 4,x
        cmpa #64
        bhs enemy_integrate
        inc 12,x
        lda #24
        sta 13,x
        ldd #0
        std 8,x
        lda 2,x
        cmpa #128
        ldd #$0240
        blo enemy_nine_velocity
        ldd #-$0240
enemy_nine_velocity
        std 6,x
        bra enemy_integrate
enemy_nine_dash
        cmpa #9
        ; State test is explicit; type is still 9 in A here.
        lda 12,x
        cmpa #1
        bne enemy_integrate
        dec 13,x
        bne enemy_integrate
        inc 12,x
        ldd #0
        std 6,x
        ldd #$0300
        std 8,x
enemy_integrate
        ldd 2,x
        addd 6,x
        std 2,x
        cmpa #8
        blo enemy_gone
        cmpa #248
        bhs enemy_gone
        ldd 4,x
        addd 8,x
        std 4,x
        cmpa #168
        bhs enemy_gone
        lda 1,x
        lsla
        ldu #enemy_art_ids
        leau a,u
        lda 11,x
        bita #4
        beq enemy_anim_zero
        leau 1,u
enemy_anim_zero
        lda ,u
        sta 14,x
        lda 1,x
        cmpa #9
        beq enemy_skip_cooldown
        tst 13,x
        beq enemy_shoot_now
        dec 13,x
        bra move_enemy_skip
enemy_skip_cooldown
        lda 11,x
        anda #31
        bne move_enemy_skip
enemy_shoot_now
        lda #48
        sta 13,x
        lda 4,x
        adda #24
        cmpa <player_y
        bhs move_enemy_skip
        lda 2,x
        sta <aim_x
        lda 4,x
        sta <aim_y
        jsr aimed_shot
        ldx <entity_ptr
        bra move_enemy_skip
enemy_exploding
        dec 11,x
        beq enemy_gone
        lda #EXPLOSION_ART
        ldb 11,x
        cmpb #6
        bhi explosion_art_set
        inca
        cmpb #3
        bhi explosion_art_set
        inca
explosion_art_set
        sta 14,x
        bra move_enemy_skip
enemy_gone
        clr ,x
move_enemy_skip
        leax 32,x
        cmpx #ENTITIES+7*32
        lblo move_enemy_next
        rts

; Eight-direction aimed shot, bounded pool identical in size to the original.
aimed_shot
        ldu #ENTITIES+10*32
aim_find_slot
        tst ,u
        beq aim_found_slot
        leau 32,u
        cmpu #ENTITIES+18*32
        blo aim_find_slot
        rts
aim_found_slot
        ldd #0
        std <aim_vx
        ldd #$0300
        std <aim_vy
        lda <player_x
        adda #8
        cmpa <aim_x
        blo aim_left
        suba <aim_x
        cmpa #12
        blo aim_horizontal_ready
        ldd #$0200
        bra aim_store_vx
aim_left
        lda <aim_x
        suba <player_x
        suba #8
        cmpa #12
        blo aim_horizontal_ready
        ldd #-$0200
aim_store_vx
        std <aim_vx
aim_horizontal_ready
        lda <player_y
        cmpa <aim_y
        bhs aim_vertical_ready
        ldd #-$0300
        std <aim_vy
aim_vertical_ready
        lda #1
        sta ,u
        lda #8
        sta 1,u
        lda <aim_x
        clrb
        std 2,u
        lda <aim_y
        std 4,u
        ldd <aim_vx
        std 6,u
        ldd <aim_vy
        std 8,u
        lda #BULLET_ART
        sta 14,u
        rts

; AABB helpers. Return A=1 on overlap; all rectangles stay inside 256x176.
rect_hit
        lda <rect_ax
        adda <rect_aw
        bcs rect_xa_ok
        cmpa <rect_bx
        bls rect_miss
rect_xa_ok
        lda <rect_bx
        adda <rect_bw
        bcs rect_xb_ok
        cmpa <rect_ax
        bls rect_miss
rect_xb_ok
        lda <rect_ay
        adda <rect_ah
        bcs rect_ya_ok
        cmpa <rect_by
        bls rect_miss
rect_ya_ok
        lda <rect_by
        adda <rect_bh
        bcs rect_yb_ok
        cmpa <rect_ay
        bls rect_miss
rect_yb_ok
        lda #1
        rts
rect_miss
        clra
        rts
player_rect
        lda <player_x
        adda #3
        sta <rect_ax
        lda <player_y
        adda #3
        sta <rect_ay
        lda #10
        sta <rect_aw
        sta <rect_ah
        rts
enemy_rect
        lda 1,x
        anda #15
        lsla
        lsla
        ldu #original_enemy_boxes
        leau a,u
        lda ,u+
        adda 4,x
        sta <rect_by
        lda ,u+
        adda 2,x
        sta <rect_bx
        lda ,u+
        sta <rect_bh
        lda ,u
        sta <rect_bw
        rts
hit_enemies
        ldx #ENTITIES
hit_enemy_next
        stx <entity_ptr
        lda ,x
        cmpa #1
        bne hit_enemy_skip
        jsr enemy_rect
        ldy #ENTITIES+7*32
hit_enemy_arrow
        tst ,y
        beq hit_arrow_next
        jsr player_shot_rect
        jsr rect_hit
        tsta
        beq hit_arrow_next
        lda 1,y
        cmpa #6
        bhs hit_enemy_power_weapon
        clr ,y
        ldx <entity_ptr
        jsr sfx_hit
        dec 10,x
        bne hit_enemy_skip
hit_enemy_power_weapon
        ldx <entity_ptr
        clr 10,x
        jsr kill_enemy
        bra hit_enemy_skip
hit_arrow_next
        leay 32,y
        cmpy #ENTITIES+10*32
        blo hit_enemy_arrow
hit_enemy_skip
        ldx <entity_ptr
        leax 32,x
        cmpx #ENTITIES+7*32
        blo hit_enemy_next
        rts
kill_enemy
        jsr sfx_explosion
        lda #2
        sta ,x
        lda #9
        sta 11,x
        lda #EXPLOSION_ART
        sta 14,x
        lda 1,x
        anda #15
        lsla
        ldu #combat_points
        ldd a,u
        addd <score
        bcc score_store
        ldd #65535
score_store
        std <score
        cmpd <high_score
        bls no_high_score
        std <high_score
no_high_score
        ldd <kills
        addd #1
        std <kills
        lda #1
        sta <hud_dirty
        rts
touch_player
        jsr shield_intercepts
        lda <ability_kind
        cmpa #2
        lbeq touch_return
        tst <player_invul
        lbne touch_return
        tst <combat_status
        lbne touch_return
        jsr player_rect
        ldx #ENTITIES
touch_enemy_loop
        lda ,x
        cmpa #1
        bne touch_enemy_skip
        jsr enemy_rect
        jsr rect_hit
        tsta
        beq touch_enemy_skip
        lda <ability_kind
        cmpa #3
        lbne player_hit
        jsr kill_enemy
touch_enemy_skip
        leax 32,x
        cmpx #ENTITIES+7*32
        blo touch_enemy_loop
        ldx #ENTITIES+10*32
touch_bullet_loop
        tst ,x
        beq touch_bullet_skip
        lda 2,x
        suba #3
        sta <rect_bx
        lda 4,x
        suba #3
        sta <rect_by
        lda #6
        sta <rect_bw
        sta <rect_bh
        jsr rect_hit
        tsta
        beq touch_bullet_skip
        clr ,x
        lda <ability_kind
        cmpa #3
        lbne player_hit
touch_bullet_skip
        leax 32,x
        cmpx #ENTITIES+18*32
        blo touch_bullet_loop
        lda <ability_kind
        cmpa #3
        beq touch_return
        lda <boss_state
        cmpa #1
        lbne touch_return
        lda <boss_x
        sta <rect_bx
        lda <boss_y
        sta <rect_by
        lda #40
        sta <rect_bw
        sta <rect_bh
        jsr rect_hit
        tsta
        beq touch_return
player_hit
        jsr sfx_player
        lda #1
        sta <combat_status
        lda #72
        sta <death_clock
        dec <player_lives
        lda #1
        sta <hud_dirty
touch_return
        rts

; Original terrain predicate $620c: $43-$7f and $a3-$df are solid.
terrain_check
        lda <player_fx
        sta <old_player_fx
        lda <player_fy
        sta <old_player_fy
        lda <player_x
        sta <old_player_x
        lda <player_y
        sta <old_player_y
        rts
terrain_after_move
        lda <player_x
        adda #4
        sta <terrain_x
        lda <player_y
        adda #13
        sta <terrain_y
        jsr terrain_tile
        tsta
        beq terrain_block
        lda <player_x
        adda #11
        sta <terrain_x
        jsr terrain_tile
        tsta
        bne terrain_return
terrain_block
        lda <old_player_x
        sta <player_x
        lda <old_player_y
        sta <player_y
        lda <old_player_fx
        sta <player_fx
        lda <old_player_fy
        sta <player_fy
terrain_return
        rts
terrain_tile
        lda #7
        sta $ffa6
        clra
        ldb <terrain_y
        addd <camera_y
        lslb
        rola
        lslb
        rola
        andb #$e0
        addd #$c000
        tfr d,u
        lda <terrain_x
        lsra
        lsra
        lsra
        lda a,u
        jsr items_terrain
        ; MSX $620C returns carry for SOLID tiles, not for walkable ones.
        ; Starting grass $80..$82 must remain traversable.
        suba #$43
        cmpa #$3d
        blo terrain_solid
        suba #$60
        cmpa #$3d
        blo terrain_solid
        ldb #1
        bra terrain_tile_restore
terrain_solid
        clrb
terrain_tile_restore
        lda #$0d
        sta $ffa6
        tfr b,a
        rts

start_boss
        ldx #ENTITIES
start_boss_clear
        clr ,x
        leax 32,x
        cmpx #ENTITY_END
        blo start_boss_clear
        clr <wave_left
        lda #1
        sta <boss_state
        lda #BOSS_HITS
        sta <boss_hp
        lda #112
        sta <boss_x
        lda #32
        sta <boss_y
        lda #40
        sta <boss_wait
        rts
update_boss
        lda <boss_state
        cmpa #2
        bne boss_still_alive
        dec <boss_wait
        lbne boss_update_return
        lda #3
        sta <boss_state
        sta <combat_status
        lda #1
        sta <unlocked_exit
        lda #$12
        sta $ff9a
        rts
boss_still_alive
        cmpa #1
        lbne boss_update_return
        ldd <boss_clock
        addd #1
        std <boss_clock
        tst <boss_wait
        beq boss_choose_direction
        dec <boss_wait
        bra boss_attack
boss_choose_direction
        lda <player_x
        adda #8
        anda #$fc
        sta <aim_x
        lda <boss_x
        adda #12
        anda #$fc
        cmpa <aim_x
        blo boss_move_right
        bhi boss_move_left
        lda #40
        sta <boss_wait
        bra boss_attack
boss_move_right
        lda <boss_x
        adda #2
        cmpa #191
        bls boss_store_x
        lda #191
        bra boss_store_x
boss_move_left
        lda <boss_x
        suba #2
        cmpa #32
        bhs boss_store_x
        lda #32
boss_store_x
        sta <boss_x
boss_attack
        lda <boss_clock+1
        anda #15
        bne boss_satellite_test
        lda <boss_x
        adda #20
        sta <aim_x
        lda <boss_y
        adda #36
        sta <aim_y
        jsr aimed_shot
boss_satellite_test
        lda <boss_clock+1
        ldb #0
        cmpa #85
        beq boss_release_satellite
        ldb #1
        cmpa #170
        beq boss_release_satellite
        ldb #2
        cmpa #255
        lbne boss_update_return
boss_release_satellite
        lda #32
        mul
        addd #ENTITIES
        tfr d,x
        tst ,x
        lbne boss_update_return
        lda #1
        sta ,x
        sta 10,x
        lda #12
        sta 1,x
        lda <boss_clock+1
        sta 11,x
boss_update_return
        rts
move_satellite
        inc 11,x
        lda 11,x
        lsra
        anda #31
        ldu #orbit_x
        lda a,u
        adda <boss_x
        adda #20
        clrb
        std 2,x
        lda 11,x
        lsra
        anda #31
        ldu #orbit_y
        lda a,u
        adda <boss_y
        adda #20
        std 4,x
        lda #12*2
        ldu #enemy_art_ids
        ldb 11,x
        bitb #4
        beq satellite_frame
        inca
satellite_frame
        lda a,u
        sta 14,x
        lbra move_enemy_skip

hit_boss
        lda <boss_state
        cmpa #1
        bne hit_boss_return
        lda <boss_x
        adda #7
        sta <rect_bx
        lda <boss_y
        adda #8
        sta <rect_by
        lda #26
        sta <rect_bw
        lda #16
        sta <rect_bh
        ldy #ENTITIES+7*32
boss_hit_arrow
        tst ,y
        beq boss_next_arrow
        jsr player_shot_rect
        jsr rect_hit
        tsta
        beq boss_next_arrow
        clr ,y
        jsr sfx_hit
        lda 1,y
        cmpa #6
        blo boss_single_damage
        lda <boss_hp
        cmpa #2
        blo boss_single_damage
        dec <boss_hp
boss_single_damage
        dec <boss_hp
        lda #2
        sta <boss_flash
        tst <boss_hp
        bne boss_next_arrow
        jsr sfx_boss
        lda #2
        sta <boss_state
        lda #24
        sta <boss_wait
        ldx #ENTITIES
boss_defeat_clear
        clr ,x
        leax 32,x
        cmpx #ENTITY_END
        blo boss_defeat_clear
        ldd <score
        addd #1000
        std <score
        cmpd <high_score
        bls boss_score_ready
        std <high_score
boss_score_ready
        lda #1
        sta <hud_dirty
        rts
boss_next_arrow
        leay 32,y
        cmpy #ENTITIES+10*32
        blo boss_hit_arrow
hit_boss_return
        rts

; Generic masked sprites, clipped as complete images, with per-slot backgrounds.
combat_draw
        jsr draw_boss
        clr <entity_index
        ldx #ENTITIES
combat_draw_next
        stx <entity_ptr
        tst ,x
        lbeq combat_draw_skip
        lda 14,x
        ldu #all_art_banks
        lda a,u
        sta $ffa6
        lda 14,x
        ldb #8
        mul
        addd #all_art
        tfr d,u
        stu <art_ptr
        lda 6,u
        bpl combat_positive_x
        adda 2,x
        lbcc combat_draw_skip
        bra combat_x_ready
combat_positive_x
        adda 2,x
        lbcs combat_draw_skip
combat_x_ready
        sta <art_x
        lda 7,u
        bpl combat_positive_y
        adda 4,x
        lbcc combat_draw_skip
        bra combat_y_ready
combat_positive_y
        adda 4,x
        lbcs combat_draw_skip
combat_y_ready
        sta <art_y
        adda 5,u
        lbcs combat_draw_skip
        cmpa #176
        lbhi combat_draw_skip
        lda 4,u
        sta <art_width
        lsla
        adda <art_x
        lbcs combat_draw_skip
        lda 5,u
        sta <art_height
        sta <art_lines
        ldd ,u
        lda <art_x
        bita #1
        beq combat_even_art
        ldd 2,u
        bra combat_art_selected
combat_even_art
        ldd ,u
combat_art_selected
        std <art_source
        lda <art_x
        lsra
        sta <span_x
        sta 20,x
        lda <art_width
        sta <span_n
        sta 21,x
        ldu #masked_row_table
        lsla
        ldd a,u
        std <blit_fn
        lda <entity_index
        cmpa #18
        bne combat_regular_mask
        tst <token_family
        beq combat_regular_mask
        ldd #token_masked_row
        std <blit_fn
combat_regular_mask
        lda <art_height
        sta 22,x
        clra
        ldb <ring_head
        addb <art_y
        adca #0
        std <span_row
        std 18,x
        lda #1
        sta 17,x
        lda <entity_index
        cmpa #18
        bne combat_draw_standard_buffer
        ldy #$0f00
        bra combat_draw_buffer_ready
combat_draw_standard_buffer
        adda #$11
        clrb
        tfr d,y
combat_draw_buffer_ready
        jsr framebuffer_pointer
combat_draw_row
        ldx <art_source
        jsr [blit_fn]
        stx <art_source
        jsr advance_span
        dec <art_lines
        bne combat_draw_row
combat_draw_skip
        ldx <entity_ptr
        leax 32,x
        inc <entity_index
        lda <entity_index
        cmpa #19
        lblo combat_draw_next
        lda #$0d
        sta $ffa6
        rts

erase_boss
        tst <boss_drawn
        beq erase_boss_return
        ldd <boss_old_row
        std <span_row
        lda <boss_old_x
        sta <span_x
        lda #20
        sta <span_n
        lda #44
        sta <art_lines
        ldx #$2300
erase_boss_line
        jsr write_span
        ldd <span_row
        addd #1
        std <span_row
        dec <art_lines
        bne erase_boss_line
        clr <boss_drawn
erase_boss_return
        rts
draw_boss
        lda <boss_state
        lbeq draw_boss_return
        cmpa #3
        lbeq draw_boss_return
        cmpa #2
        bne boss_draw_normal
        lda <boss_wait
        bita #2
        bne draw_boss_return
boss_draw_normal
        lda #14
        sta $ffa6
        lda <boss_clock+1
        anda #8
        lsra
        lsra
        ldx #boss_pointers
        ldx a,x
        stx <boss_source
        clra
        ldb <ring_head
        addb <boss_y
        adca #0
        subd #4
        std <span_row
        std <boss_old_row
        lda <boss_x
        lsra
        sta <span_x
        sta <boss_old_x
        lda #20
        sta <span_n
        lda #44
        sta <art_lines
        ldy #$2300
boss_draw_line
        jsr framebuffer_pointer
        ldb #20
boss_save_line
        lda ,u+
        sta ,y+
        decb
        bne boss_save_line
        lda <art_lines
        cmpa #40
        bls boss_copy_art
        ldx #SCANLINE
        ldb #20
boss_bar_line
        lda #$11
        cmpb <boss_hp
        bhi boss_bar_empty
        lda #$ff
boss_bar_empty
        sta ,x+
        decb
        bne boss_bar_line
        ldx #SCANLINE
        bra boss_write_line
boss_copy_art
        ldx <boss_source
        leau 20,x
        stu <boss_source
boss_write_line
        jsr write_span
        ldd <span_row
        addd #1
        std <span_row
        dec <art_lines
        bne boss_draw_line
        lda #1
        sta <boss_drawn
draw_boss_return
        rts

hud_update
        tst <hud_dirty
        beq hud_update_return
        clr <hud_dirty
        lda #$0d
        sta $ffa6
        ldd <score
        jsr decimal_digits
        lda #2
        sta <hud_col
        jsr hud_six_digits
        ldd <high_score
        jsr decimal_digits
        lda #11
        sta <hud_col
        jsr hud_six_digits
        lda #21
        sta <hud_col
        clrb
        jsr hud_digit
        inc <hud_col
        ldb <player_lives
        beq hud_rest_zero
        decb
hud_rest_zero
        jsr hud_digit
        jsr draw_hud
hud_update_return
        rts
decimal_digits
        std <aim_vx
        clr <hud_digits
        ldx #decimal_divisors
        ldy #hud_digits+1
        lda #5
        sta <digit_count
        ldd <aim_vx
decimal_digit_loop
        clr <digit_temp
decimal_subtract
        cmpd ,x
        blo decimal_digit_ready
        subd ,x
        inc <digit_temp
        bra decimal_subtract
decimal_digit_ready
        pshs d
        lda <digit_temp
        sta ,y+
        puls d
        leax 2,x
        dec <digit_count
        bne decimal_digit_loop
        rts
hud_six_digits
        ldy #hud_digits
        lda #6
        sta <digit_count
hud_digit_next
        ldb ,y+
        jsr hud_digit
        inc <hud_col
        dec <digit_count
        bne hud_digit_next
        rts
hud_digit
        pshs x,y
        addb #16
        lda #32
        mul
        addd #$a000
        tfr d,x
        lda <hud_col
        ldb #4
        mul
        addd #$d400
        tfr d,u
        lda #8
        sta <digit_temp
hud_font_row
        ldd ,x++
        std ,u++
        ldd ,x++
        std ,u++
        leau 124,u
        dec <digit_temp
        bne hud_font_row
        puls x,y,pc
decimal_divisors
        fdb 10000,1000,100,10,1
orbit_x
        fcb 28,27,26,23,20,16,11,5,0,-5,-11,-16,-20,-23,-26,-27
        fcb -28,-27,-26,-23,-20,-16,-11,-5,0,5,11,16,20,23,26,27
orbit_y
        fcb 0,5,9,13,17,20,22,24,24,24,22,20,17,13,9,5
        fcb 0,-5,-9,-13,-17,-20,-22,-24,-24,-24,-22,-20,-17,-13,-9,-5
        include "combat_data.inc"
