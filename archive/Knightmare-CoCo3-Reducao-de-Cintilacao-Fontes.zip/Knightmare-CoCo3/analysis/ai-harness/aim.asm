        org $0b00
        jsr $57c4
        sta $0be4

harness_done
        bra harness_done
