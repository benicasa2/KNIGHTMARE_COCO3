# Knightmare CoCo 3 — combate da primeira fase

Incremento nativo em Assembly 6809, para CoCo 3 com 128 KiB: disparos, inimigos, colisões, vidas, pontuação e o primeiro chefe. Há discos para DAC interno de 6 bits e Orchestra-90 CC. Mantém teclado, joystick e rolagem da versão anterior.

**Ainda é um protótipo da primeira fase.** Não é a conversão completa nem uma reprodução exata do MSX. Os gráficos e diversas tabelas vêm da ROM fornecida; trajetórias, formações, temporização e renascimento contêm adaptações. Os outros chefes, as fases seguintes e os itens/armas avançadas ainda não estão integrados. O áudio mantém o trecho musical sintetizado da etapa anterior; não há efeitos de combate sincronizados nem o sequenciador original completo.

## Executar

Abra `EXECUTAR-DAC6.cmd` ou `EXECUTAR-ORCH90.cmd` e aguarde o carregamento. Os scripts procuram o XRoar instalado neste computador. Para outra instalação:

```powershell
python tools/run_demo.py --variant DAC6 --xroar C:\caminho\xroar.exe
python tools/run_demo.py --variant ORCH90 --xroar C:\caminho\xroar.exe
```

Alternativamente, monte `bin/DAC6.DSK` ou `bin/ORCH90.DSK` no drive 0 e digite `RUN"START"`. O script requer as ROMs de sistema do usuário `coco3.rom` e `disk11.rom` ao lado do XRoar; elas não estão incluídas. Use saída RGB. A variante Orchestra usa Multi-Pak emulado: Orchestra-90 no slot 0 e disco no slot 3, com slot 3 selecionado.

| Controle | Ação |
| --- | --- |
| Setas ou W/A/S/D | Mover; diagonais permitidas |
| Espaço ou botão do joystick selecionado | Disparo contínuo; até três flechas simultâneas |
| K | Somente teclado, modo inicial |
| J / L | Ativar joystick analógico direito / esquerdo |
| P | Pausar/retomar a ação e a rolagem; música continua |
| R | Reiniciar a primeira fase, mantendo o recorde da sessão |

Se não houver joystick conectado, use K. Controles USB devem ser associados às portas analógicas pelo XRoar. A fase rola automaticamente e termina na arena do primeiro chefe. A borda fica vermelha no fim das vidas e verde após derrotar o chefe; use R para recomeçar. Não há passagem para a segunda fase nesta versão.

## Conteúdo

- `src/combat.asm` e `combat_state.inc`: projéteis, oleadas, colisões, chefe, pontuação e composição de sprites.
- `src/gameplay.asm`: teclado, joysticks, movimento e rolagem circular.
- `src/hardware_probe.asm`: inicialização, MMU e síntese de áudio por FIRQ.
- `src/combat_data.inc`: constantes geradas da ROM; `assets/combat-bank.bin`: arte de combate.
- `analysis/COMBATE.md`: proveniência, implementação, adaptações e limitações dos testes.
- `analysis/*-combat-verification.json` e `*-combat-*.png`: cenários e imagens dos binários atuais no XRoar.
- `analysis/*-controls-verification.json`: regressão de entrada e rolagem, executada com combate desativado pelo depurador.
- `analysis/RELATORIO.md`: histórico REA/Ghidra; `CONTROLES-E-ROLAGEM.md`: histórico da etapa anterior.
- `STATUS.json`, `analysis/build.json`, `MANIFEST.json`: alcance, compilação e hashes.

## Compilar e verificar

Requer Python 3, LWASM e XRoar. Não usa bibliotecas Python adicionais.

```powershell
python tools/build.py --lwasm C:\caminho\lwasm.exe
python tools/verify_combat.py --xroar C:\caminho\xroar.exe
python tools/verify_controls_scroll.py --xroar C:\caminho\xroar.exe
```

Os testes de combate executam o 6809 real emulado, com posições e impactos preparados pelo depurador. Conferem o framebuffer byte a byte contra um renderizador independente. Não equivalem a uma partida completa vencida sem intervenção. A regressão de entrada fornece sinais externos nas leituras da PIA; não houve teste com joystick físico ou CoCo real. Não foi certificado desempenho constante em todas as combinações de objetos.

Para regenerar recursos de combate a partir da ROM do usuário, depois dos recursos gráficos básicos:

```powershell
python tools/prepare_combat.py --rom C:\caminho\Knightmare.rom
```

A ROM original foi preservada, SHA-256 `589b2fd276d84827bb1b033f43a0cd5ab0aa9da3c8784cac2f62474fed00aae3`. As ferramentas em `third_party/knightmare` vêm de [antxiko/Knightmare-disassembly](https://github.com/antxiko/Knightmare-disassembly), com origem e licença preservadas. O histórico REA/Ghidra usa [REA-RETRO-9](https://github.com/benicasa2/REA-RETRO-9); seus arquivos estão em `third_party/rea`. O WAV de referência em `reference/` é do openMSX, não uma gravação desta versão no CoCo.
