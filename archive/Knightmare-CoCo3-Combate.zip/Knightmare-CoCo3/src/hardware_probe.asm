; Knightmare / CoCo 3: native first-stage combat prototype.
; 6809 only, 128 KiB, RGB palette, 256x192x16, two selectable DAC backends.
; Original tilemap and walking sprites; audio is a captured PSG trace.
; LWASM: --format=decb --define=ORCH90=0 (or 1).
        org $0c00
state_begin
phase_a rmb 2
phase_b rmb 2
phase_c rmb 2
phase_n rmb 2
parameters
step_a rmb 2
step_b rmb 2
step_c rmb 2
step_n rmb 2
amp_a rmb 1
amp_b rmb 1
amp_c rmb 1
td_a rmb 1
td_b rmb 1
td_c rmb 1
nd_a rmb 1
nd_b rmb 1
nd_c rmb 1
parameters_end
noise_hi rmb 1
noise_mid rmb 1
noise_lo rmb 1
noise_gate rmb 1
mix rmb 1
frame_acc rmb 1
frame_due rmb 1
trace_ptr rmb 2
frames_played rmb 2
        include "game_state.inc"
        include "combat_state.inc"
state_end

        org $3000
start
        orcc #$50
        lds #$2fff
        clra
        tfr a,dp
        sta $ffdf
        sta $ffd9
        lda #$4c
        sta $ff90
        clr $ff91
        clr $ff92
        clr $ff93
        ldx #$ffa0
        lda #$38
map_default
        sta ,x+
        inca
        cmpa #$40
        blo map_default
        lda #$80
        sta $ff98
        lda #$1a
        sta $ff99
        lda #$c0
        sta $ff9d
        clr $ff9e
        clr $ff9c
        clr $ff9f
        clr $ff9a
        ldx #palette
        ldu #$ffb0
        ldb #16
copy_palette
        lda ,x+
        sta ,u+
        decb
        bne copy_palette
        ldx #state_begin
clear_state
        clr ,x+
        cmpx #state_end
        blo clear_state
        lda #$0c
        tfr a,dp
        lda #1
        sta <noise_lo
        jsr game_init
        ldx #trace_data
        stx <trace_ptr
        jsr next_frame
        ; Disable PIA IRQ sources; GIME FIRQ owns audio timing.
        lda $ff01
        anda #$f6
        sta $ff01
        lda $ff03
        anda #$f6
        sta $ff03
        lda $ff21
        anda #$f7
        sta $ff21
        lda $ff23
        ifne ORCH90
        anda #$f7
        else
        ora #$08
        endc
        sta $ff23
        ; PIA1 PA bits 7..2 output, low two input/control bits preserved.
        lda $ff21
        anda #$fb
        sta $ff21
        lda #$fc
        sta $ff20
        lda $ff21
        ora #$04
        sta $ff21
        ; $FFF6 is always ROM on the CoCo 3 and vectors through RAM $FEF4.
        lda #$7e
        sta $fef4
        ldd #audio_firq
        std $fef5
        lda #$5c
        sta $ff90
        lda #$20
        sta $ff91
        lda #$20
        sta $ff93
        ; GIME timer = 910+2 ticks, 3579545/912 = 3924.94 samples/s.
        ldb #$8e
        stb $ff95
        lda #$03
        sta $ff94
        andcc #$bf
main_loop
        tst <frame_due
        beq main_loop
        orcc #$40
        clr <frame_due
        jsr next_frame
        andcc #$bf
        jsr game_tick
        bra main_loop

next_frame
        ldx <trace_ptr
        cmpx #trace_end
        blo trace_valid
        ldx #trace_data
trace_valid
        ldu #parameters
        ldb #parameters_end-parameters
parameter_copy
        lda ,x+
        sta ,u+
        decb
        bne parameter_copy
        stx <trace_ptr
        ldd <frames_played
        addd #1
        std <frames_played
        rts

audio_firq
        pshs d
        lda $ff93
        ldd <phase_n
        addd <step_n
        std <phase_n
        bcc noise_no_shift
        ; AY 17-bit LFSR, feedback bit0 XOR bit3.
        lda <noise_lo
        lsra
        lsra
        lsra
        eora <noise_lo
        anda #1
        tfr a,b
        lsr <noise_hi
        ror <noise_mid
        ror <noise_lo
        stb <noise_hi
noise_no_shift
        clr <noise_gate
        lda <noise_lo
        bita #1
        beq noise_ready
        lda #$80
        sta <noise_gate
noise_ready
        clr <mix
        ldd <phase_a
        addd <step_a
        std <phase_a
        anda #$80
        ora <td_a
        beq mute_a
        lda <noise_gate
        ora <nd_a
        beq mute_a
        lda <amp_a
        sta <mix
mute_a
        ldd <phase_b
        addd <step_b
        std <phase_b
        anda #$80
        ora <td_b
        beq mute_b
        lda <noise_gate
        ora <nd_b
        beq mute_b
        lda <amp_b
        adda <mix
        sta <mix
mute_b
        ldd <phase_c
        addd <step_c
        std <phase_c
        anda #$80
        ora <td_c
        beq mute_c
        lda <noise_gate
        ora <nd_c
        beq mute_c
        lda <amp_c
        adda <mix
        sta <mix
mute_c
        lda <mix
output_sample
        ifne ORCH90
        sta $ff7a
        sta $ff7b
        else
        anda #$fc
        sta $ff20
        endc
        lda <frame_acc
        adda #2
        cmpa #131
        blo frame_wait
        suba #131
        inc <frame_due
frame_wait
        sta <frame_acc
        puls d
        rti

        include "gameplay.asm"
        include "combat.asm"
palette
        include "palette.inc"
trace_data
        includebin "../assets/audio-trace.bin"
trace_end
program_end
        end start
