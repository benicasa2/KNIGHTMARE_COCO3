# Knightmare CoCo 3 — versão otimizada, sem música

Música de fundo removida das duas variantes, DAC6 e Orchestra-90 CC. Há efeitos por evento para disparo, impacto, explosão, morte do jogador e derrota do primeiro chefe. A interrupção de áudio fica desativada entre os efeitos. O jogo continua em Assembly 6809 para CoCo 3 com 128 KiB.

Também foram otimizadas as cópias de vídeo, a composição dos sprites e a troca de bancos MMU. O relógio da ação agora usa a interrupção vertical do GIME, independente do som. As velocidades, os limites de tiros e as cadências da versão anterior foram preservados.

Nos cenários controlados do XRoar, o trabalho médio por atualização caiu de **27,4 para 9,7 ms** no cenário leve e de **179,4 para 59,0 ms** no cenário de 18 objetos. Isso representa cerca de 64–67% menos tempo nesses testes, não FPS garantido em toda a fase. Cenas muito carregadas ainda podem desacelerar. Veja `analysis/OTIMIZACAO.md` e `performance.json`.

## Executar a nova versão

Feche o XRoar antigo, extraia o pacote novo e abra `EXECUTAR-DAC6.cmd` ou `EXECUTAR-ORCH90.cmd`. Pressionar R no jogo já aberto não carrega o código novo.

Os scripts procuram a instalação existente do XRoar deste computador. Para outra instalação:

```powershell
python tools/run_demo.py --variant DAC6 --xroar C:\caminho\xroar.exe
python tools/run_demo.py --variant ORCH90 --xroar C:\caminho\xroar.exe
```

Ou monte `bin/DAC6.DSK` / `bin/ORCH90.DSK` no drive 0 e digite `RUN"START"`. As ROMs de sistema do usuário `coco3.rom` e `disk11.rom` devem estar ao lado do XRoar e não são incluídas. Use saída RGB. A variante Orchestra configura Multi-Pak com Orchestra-90 no slot 0 e disco no slot 3, selecionando o slot 3.

| Controle | Ação |
| --- | --- |
| Setas ou W/A/S/D | Mover; diagonais permitidas |
| Espaço ou botão do joystick selecionado | Disparo contínuo; até três flechas |
| K | Somente teclado, modo inicial |
| J / L | Joystick analógico direito / esquerdo; teclado também ativo |
| P | Pausar/retomar; um efeito curto já iniciado termina normalmente |
| R | Reiniciar a primeira fase, preservando o recorde da sessão |

Sem joystick conectado, use K. Controles USB devem ser associados às portas analógicas no XRoar. Borda vermelha indica fim das vidas; verde indica vitória sobre o primeiro chefe. Use R para recomeçar.

## Alcance e fidelidade

É um protótipo de combate da primeira fase e seu chefe. Mantém mapa e arte extraídos da ROM, disparos, inimigos, colisões, explosões, vidas e pontuação. Não é ainda a conversão completa nem uma reprodução exata do MSX: trajetórias, formações, renascimento e partes do chefe contêm adaptações. Faltam itens, armas avançadas, outras fases e chefes.

Os efeitos usam capturas isoladas das rotinas originais do PSG, convertidas previamente para PCM. A saída é aproximada: DAC6 quantiza em seis bits; Orchestra usa oito bits. Um efeito toca por vez, com prioridade; a morte do jogador reutiliza o efeito de explosão. Não há música nem sequenciador musical executando no CoCo. Os arquivos de referência musical preservados em `reference/` são históricos de análise e não são carregados pelo jogo.

## Fontes, compilação e testes

- `src/hardware_probe.asm`: inicialização e relógio vertical.
- `src/audio_sfx.asm`: efeitos PCM e prioridades; `assets/sfx-*.pcm`: amostras.
- `src/gameplay.asm`, `src/combat.asm`, `src/masked_rows.inc`: ação e desenho otimizados.
- `analysis/OTIMIZACAO.md`, `performance.json`, `sfx.json`: mudanças e evidências.
- `analysis/*-combat-verification.json`: combate, setas/WASD com combate ativo e efeitos.
- `analysis/*-controls-verification.json`: regressão de teclado, joystick e rolagem com combate desativado pelo depurador.
- `analysis/graphics-preservation.json`: nove imagens de combate por variante, idênticas à versão anterior.
- `analysis/COMBATE.md`, `CONTROLES-CORRIGIDOS.md`, `RELATORIO.md`: histórico das etapas e da análise REA/Ghidra.

Requer Python 3, LWASM e XRoar, sem pacotes Python adicionais:

```powershell
python tools/prepare_sfx.py
python tools/build.py --lwasm C:\caminho\lwasm.exe
python tools/verify_combat.py --xroar C:\caminho\xroar.exe
python tools/verify_controls_scroll.py --xroar C:\caminho\xroar.exe
python tools/benchmark_combat.py --xroar C:\caminho\xroar.exe --output analysis/benchmark-local.json
```

`prepare_sfx.py` usa os registros PSG preservados em `reference/sfx-*-psg.bin`; não precisa do openMSX para recompilar. `tools/capture_sfx.tcl` documenta a captura original, para uso com a ROM do usuário e openMSX. Os testes executam código 6809 no emulador com entradas/posições preparadas pelo depurador. Não são uma partida completa sem intervenção, um teste com joystick físico ou uma validação em CoCo real.

A ROM do usuário permanece intacta, SHA-256 `589b2fd276d84827bb1b033f43a0cd5ab0aa9da3c8784cac2f62474fed00aae3`. A análise utiliza [REA-RETRO-9](https://github.com/benicasa2/REA-RETRO-9), Ghidra e a desassemblagem de [antxiko](https://github.com/antxiko/Knightmare-disassembly). Origens e licenças das ferramentas estão em `third_party/`.
