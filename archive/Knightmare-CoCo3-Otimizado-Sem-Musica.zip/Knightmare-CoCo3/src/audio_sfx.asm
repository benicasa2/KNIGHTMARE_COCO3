; Original PSG effects rendered offline to unsigned 8-bit PCM at 3924.94 Hz.
; One priority voice; no music synthesis or timer FIRQ between effects.
sound_stop
        pshs cc,a
        orcc #$40
        clr $ff93
        clr <sfx_priority
        lda #128
        ifne ORCH90
        sta $ff7a
        sta $ff7b
        else
        sta $ff20
        endc
        puls cc,a,pc

sfx_shot
        pshs a
        lda #1
        bra request_sfx
sfx_hit
        pshs a
        lda #2
        bra request_sfx
sfx_explosion
        pshs a
        lda #3
        bra request_sfx
sfx_player
        pshs a
        lda #4
        bra request_sfx
sfx_boss
        pshs a
        lda #5
request_sfx
        pshs cc,d,x
        orcc #$40
        cmpa <sfx_priority
        blo sfx_denied
        sta <sfx_priority
        deca
        lsla
        lsla
        ldx #sfx_table
        leax a,x
        ldd ,x
        std <sfx_ptr
        ldd 2,x
        std <sfx_end
        lda $ff93
        lda #$20
        sta $ff93
sfx_denied
        puls cc,d,x
        puls a,pc

audio_firq
        pshs d,x
        lda $ff93
        ldx <sfx_ptr
        lda ,x+
        stx <sfx_ptr
output_sample
        ifne ORCH90
        sta $ff7a
        sta $ff7b
        else
        anda #$fc
        sta $ff20
        endc
        cmpx <sfx_end
        blo sfx_sample_done
        clr $ff93
        clr <sfx_priority
        lda #128
        ifne ORCH90
        sta $ff7a
        sta $ff7b
        else
        sta $ff20
        endc
sfx_sample_done
        puls d,x
        rti

sfx_table
        fdb pcm_shot,pcm_shot_end
        fdb pcm_hit,pcm_hit_end
        fdb pcm_explosion,pcm_explosion_end
        fdb pcm_explosion,pcm_explosion_end
        fdb pcm_boss,pcm_boss_end
pcm_shot
        includebin "../assets/sfx-shot.pcm"
pcm_shot_end
pcm_hit
        includebin "../assets/sfx-hit.pcm"
pcm_hit_end
pcm_explosion
        includebin "../assets/sfx-explosion.pcm"
pcm_explosion_end
pcm_boss
        includebin "../assets/sfx-boss.pcm"
pcm_boss_end
