        org $0b00
        jsr $611e
        sta $0be4

harness_done
        bra harness_done
