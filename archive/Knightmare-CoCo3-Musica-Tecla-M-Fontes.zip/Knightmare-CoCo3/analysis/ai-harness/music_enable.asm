        org $0b00
        orcc #$50
        jsr $4b6a

harness_done
        bra harness_done
