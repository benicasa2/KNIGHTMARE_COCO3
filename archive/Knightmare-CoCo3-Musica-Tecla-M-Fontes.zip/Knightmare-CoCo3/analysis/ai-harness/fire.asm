        org $0b00
        ldx #$2700
        jsr $60bb

harness_done
        bra harness_done
