"""Build the native controls/scroll prototype for both DACs."""
from pathlib import Path
import argparse,struct,subprocess,json,hashlib,math
ROOT=Path(__file__).resolve().parents[1]
def rec(addr,data):return b'\0'+struct.pack('>HH',len(data),addr)+data
def decb(segments,entry):return b''.join(rec(a,d) for a,d in segments)+b'\xff\0\0'+struct.pack('>H',entry)
def disk_image(files):
 disk=bytearray(b'\xff'*(35*18*256));fat=bytearray(b'\xff'*256);granule=0
 for index,(name,typ,asc,data) in enumerate(files):
  chain=[]
  for pos in range(0,len(data),2304):
   assert granule<68
   chain.append(granule);track=granule//2
   if track>=17:track+=1
   dest=(track*18+(granule%2)*9)*256
   part=data[pos:pos+2304];disk[dest:dest+len(part)]=part;granule+=1
  for a,b in zip(chain,chain[1:]):fat[a]=b
  fat[chain[-1]]=0xc0+((len(data)-1)%2304//256+1)
  stem,ext=name.split('.');e=bytearray(32)
  e[:8]=stem.encode().ljust(8,b' ');e[8:11]=ext.encode().ljust(3,b' ')
  e[11:14]=bytes([typ,asc,chain[0]]);struct.pack_into('>H',e,14,(len(data)-1)%256+1)
  dest=(17*18+2)*256+index*32;disk[dest:dest+32]=e
 dest=(17*18+1)*256;disk[dest:dest+256]=fat
 return disk
def prepare():
 import sys
 sys.path.insert(0,str(ROOT/'tools'))
 from render_msx import RGB,render
 ref=ROOT/'reference'
 v=(ref/'action-VRAM.bin').read_bytes();r=(ref/'action-VDP_regs.bin').read_bytes()
 pix=render(v,r)
 packed=bytes(pix[i]*16+pix[i+1] for i in range(0,len(pix),2))
 (ROOT/'assets/scene.4bpp').write_bytes(packed)
 patterns=(ROOT/'assets/stages/stage1-patterns.bin').read_bytes()
 colors=(ROOT/'assets/stages/stage1-colors.bin').read_bytes()
 tiles=bytearray()
 for tile in range(256):
  for y in range(8):
   bits=patterns[tile*8+y];color=colors[tile*8+y]
   row=[(color>>4) if bits&(128>>x) else color&15 for x in range(8)]
   tiles+=bytes(row[x]*16+row[x+1] for x in range(0,8,2))
 (ROOT/'assets/stage1-packed-tiles.bin').write_bytes(tiles)
 source=(ROOT/'assets/player-walk-indexed.bin').read_bytes()
 assert len(source)==512
 sprites=bytearray()
 for frame in range(2):
  for align in range(2):
   for y in range(16):
    row=[0]*align+list(source[frame*256+y*16:frame*256+(y+1)*16])+[0]*(2-align)
    for x in range(0,18,2):
     a,b=row[x:x+2];sprites+=bytes([(0 if a else 0xf0)|(0 if b else 15),a*16+b])
 assert len(sprites)==1152
 hud=packed[176*128:192*128]
 (ROOT/'assets/player-hud-bank.bin').write_bytes(sprites+bytes(4096-len(sprites))+hud)
 palette=[]
 for rgb in RGB:
  r,g,b=[min(3,round(x/85)) for x in rgb]
  palette.append(((r>>1)<<5)|((g>>1)<<4)|((b>>1)<<3)|((r&1)<<2)|((g&1)<<1)|(b&1))
 (ROOT/'src/palette.inc').write_text('        fcb '+','.join(f'${x:02x}' for x in palette)+'\n',encoding='ascii')
 frames=(ref/'psg-frames.bin').read_bytes()
 sample_rate=3579545/912
 # About 10 seconds of original first-stage trace. No sequencer is reconstructed.
 start=round(10/(131*456/3579545));n=600
 amp=[0]+[round(85*10**((i-15)*3/20)) for i in range(1,16)]
 trace=bytearray();envelope_uses=0;noise_clamps=0
 for p in range(start*16,min((start+n)*16,len(frames)),16):
  regs=frames[p:p+16];steps=[]
  for c in range(3):
   period=max(1,regs[c*2]|((regs[c*2+1]&15)<<8))
   steps.append(round((1789772.5/(16*period))*65536/sample_rate)&65535)
  noise=max(1,regs[6]&31)
  noise_step=round((1789772.5/(16*noise))*65536/sample_rate)
  if noise_step>65535 and (regs[7]&0x38)!=0x38:noise_clamps+=1
  steps.append(min(65535,noise_step))
  vols=[]
  for c in range(3):
   value=regs[8+c]
   if value&16:envelope_uses+=1
   vols.append(amp[value&15] if not value&16 else 0)
  trace+=struct.pack('>4H',*steps)+bytes(vols)+bytes(128 if regs[7]&(1<<c) else 0 for c in range(3))+bytes(128 if regs[7]&(8<<c) else 0 for c in range(3))
 (ROOT/'assets/audio-trace.bin').write_bytes(trace)
 return dict(palette=palette,trace_frames=len(trace)//17,trace_start_frame=start,sample_rate=sample_rate,envelope_channel_frames_muted=envelope_uses,noise_frames_rate_clamped=noise_clamps)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--lwasm',required=True);args=ap.parse_args();meta=prepare()
 files=[];loader=['10 CLEAR 200,&H2BFF','20 PRINT "KNIGHTMARE CONTROLES E ROLAGEM"','30 PRINT "SETAS/WASD  K/J/L  P PAUSA  R RESET"']
 # Runtime builds the 56KiB circular framebuffer from map and packed tiles.
 # Stage map and graphics are loaded into separate physical MMU banks.
 resources=[(7,(ROOT/'assets/stages/stage1-map.bin').read_bytes()),(12,(ROOT/'assets/stage1-packed-tiles.bin').read_bytes()),(13,(ROOT/'assets/player-hud-bank.bin').read_bytes())]
 chunks=[(bank,pos,data[pos:pos+4096]) for bank,data in resources for pos in range(0,len(data),4096)]
 for i,(bank,pos,part) in enumerate(chunks):
  address=0x8000+pos
  # PSHS CC; ORCC; all RAM; map bank; copy; restore map/ROM; PULS CC,PC.
  helper=bytes.fromhex('34011a50b7ffdf86')+bytes([bank])+bytes.fromhex('b7ffa48e0e00ce')+struct.pack('>H',address)+bytes.fromhex('108e')+struct.pack('>H',len(part))+bytes.fromhex('a680a7c0313f26f8863cb7ffa4b7ffde3581')
  payload=decb([(0x0e00,part),(0x2c00,helper)],0x2c00)
  name=f'DAT{i}.BIN';files.append((name,2,0,payload));(ROOT/'bin'/name).write_bytes(payload)
  loader.append(f'{40+i*10} LOADM"DAT{i}":EXEC')
 for orch,name in [(0,'DAC6'),(1,'ORCH90')]:
  output=ROOT/f'bin/{name}.BIN'
  subprocess.run([args.lwasm,'--format=decb',f'--define=ORCH90={orch}',f'--output={output}',f'--list={ROOT}/analysis/{name}.lst',f'--symbol-dump={ROOT}/analysis/{name}.sym','hardware_probe.asm'],cwd=ROOT/'src',check=True)
  basic=loader+[f'100 LOADM"{name}":EXEC']
  disk=disk_image([('START.BAS',0,255,('\r'.join(basic)+'\r').encode('ascii')),*files,(f'{name}.BIN',2,0,output.read_bytes())])
  (ROOT/f'bin/{name}.DSK').write_bytes(disk)
  meta[name]=dict(disk_sha256=hashlib.sha256(disk).hexdigest(),binary_bytes=output.stat().st_size)
 meta.update(status='interactive controls and scroll prototype, not the complete game',ram_kib=128,framebuffer_ring_bytes=57344,framebuffer_physical_start=0,video='256x192 16 colors RGB, 176-line playfield',map_bank=7,tiles_bank=12,player_hud_bank=13,game_update_hz=(3579545/912)/(131/2)/2,scroll_pixels_per_second=(3579545/912)/(131/2)/4,source_rom_sha256='589b2fd276d84827bb1b033f43a0cd5ab0aa9da3c8784cac2f62474fed00aae3')
 (ROOT/'analysis/build.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
