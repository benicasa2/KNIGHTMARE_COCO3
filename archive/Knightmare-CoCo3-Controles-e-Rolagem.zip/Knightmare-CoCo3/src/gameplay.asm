; Native 6809 controls and scrolling of the original first-stage tilemap.
; RAM: ring $00000-$0dfff, map $0e000, tiles $18000, sprite/HUD $1a000.
; CPU $8000 is a framebuffer window; $a000 tiles; $c000 sprites/HUD or map.
TILE_ROW        equ $0d00
SAVED_PLAYER    equ $0e00
SCANLINE        equ $1000
VIEW_HEIGHT     equ 176
MAP_HEIGHT      equ 1952

game_init
        lda #$0c
        sta $ffa5
        lda #$0d
        sta $ffa6
        clr <ring_head
        clr <ring_wraps
        clr <scroll_clock
        clr <paused
        clr <sprite_valid
        clr <scroll_steps
        clr <scroll_steps+1
        lda #120
        sta <player_x
        lda #136
        sta <player_y
        clr <player_frame
        ldd #MAP_HEIGHT-VIEW_HEIGHT
        std <camera_y
        std <world_line
        clr <target_line
init_world_loop
        jsr render_world_line
        ldd <world_line
        addd #1
        std <world_line
        inc <target_line
        lda <target_line
        cmpa #VIEW_HEIGHT
        blo init_world_loop
        jsr draw_hud
        jsr draw_player
        jsr publish_head
        rts

; One interactive update per two sound frames: 29.96 Hz, two-pixel movement.
game_tick
        inc <game_divider
        lda <game_divider
        bita #1
        lbne game_return
        ldd <game_ticks
        addd #1
        std <game_ticks
        jsr poll_input
apply_input
        lda <input_bits
        eora <previous_input
        anda <input_bits
        sta <input_edges
        lda <input_bits
        sta <previous_input
        lda <input_edges
        bita #$20
        beq no_pause_key
        lda <paused
        eora #1
        sta <paused
no_pause_key
        lda <input_edges
        bita #$40
        beq no_reset_key
        jsr game_init
        rts
no_reset_key
        tst <paused
        bne game_return
        jsr move_player
        clr <scroll_due
        inc <scroll_clock
        lda <scroll_clock
        cmpa #2
        blo scroll_timer_wait
        clr <scroll_clock
        ldd <camera_y
        beq scroll_timer_wait
        inc <scroll_due
scroll_timer_wait
        lda <scroll_due
        ora <player_moved
        beq game_return
        jsr erase_player
        tst <scroll_due
        beq no_camera_step
        dec <ring_head
        bne scroll_no_wrap
        inc <ring_wraps
ring_wrapped
        nop
scroll_no_wrap
        ldd <camera_y
        subd #1
        std <camera_y
        std <world_line
        lda <ring_head
        sta <target_line
        jsr render_world_line
        jsr draw_hud
        ldd <scroll_steps
        addd #1
        std <scroll_steps
no_camera_step
        jsr draw_player
        jsr publish_head
        ldd <camera_y
        bne game_return
        tst <scroll_due
        beq game_return
camera_stopped
        nop
game_return
        rts

move_player
        clr <player_moved
        lda <input_bits
        anda #$0f
        beq movement_done
        inc <player_moved
        ; Opposite directions cancel instead of introducing an axis bias.
        anda #$0c
        cmpa #$0c
        beq horizontal_done
        lda <input_bits
        bita #4
        beq test_right
        lda <player_x
        suba #2
        bcc store_left
        clra
store_left
        sta <player_x
test_right
        lda <input_bits
        bita #8
        beq horizontal_done
        lda <player_x
        adda #2
        cmpa #239
        bls store_right
        lda #239
store_right
        sta <player_x
horizontal_done
        lda <input_bits
        anda #3
        cmpa #3
        beq movement_done
        lda <input_bits
        bita #1
        beq test_down
        lda <player_y
        suba #2
        bcc store_up
        clra
store_up
        sta <player_y
test_down
        lda <input_bits
        bita #2
        beq movement_done
        lda <player_y
        adda #2
        cmpa #160
        bls store_down
        lda #160
store_down
        sta <player_y
movement_done
        tst <player_moved
        beq walking_idle
        inc <walk_clock
        lda <walk_clock
        lsra
        lsra
        anda #1
        sta <player_frame
        rts
walking_idle
        tst <player_frame
        beq idle_frame_ready
        inc <player_moved
idle_frame_ready
        clr <player_frame
        rts

; Scan real PIA matrix, allowing simultaneous axes and fire.
; Select K=keyboard, J=right stick, L=left stick; keyboard remains active.
poll_input
        clr <input_bits
        lda #$ff
        sta $ff02
        lda $ff00
        coma
        anda #$0f
        coma
        sta <button_mask
        ldx #key_rows
        lda #$fe
        sta <key_column
        ldb #8
keyboard_scan
        lda <key_column
        sta $ff02
keyboard_read
        lda $ff00
        coma
        anda #$7f
        anda <button_mask
        sta ,x+
        lda <key_column
        orcc #1
        rola
        sta <key_column
        decb
        bne keyboard_scan
        lda #$ff
        sta $ff02
        ldx #key_definitions
key_decode
        lda ,x+
        cmpa #$ff
        beq key_decode_done
        ldu #key_rows
        lda a,u
        anda ,x+
        beq key_not_down
        lda <input_bits
        ora ,x
        sta <input_bits
key_not_down
        leax 1,x
        bra key_decode
key_decode_done
        lda <key_rows+3
        bita #2
        beq test_j_mode
        clr <input_mode
test_j_mode
        lda <key_rows+2
        bita #2
        beq test_l_mode
        lda #1
        sta <input_mode
test_l_mode
        lda <key_rows+4
        bita #2
        beq input_mode_set
        lda #2
        sta <input_mode
input_mode_set
        tst <input_mode
        beq input_done
        jsr read_joystick
input_done
        rts

; Read two thresholds per analog axis (24/40 of 63): stable centre dead zone.
; Short critical section prevents audio FIRQ from changing the shared DAC.
read_joystick
        pshs cc
        orcc #$40
        lda $ff20
        sta <saved_dac
        lda $ff23
        sta <saved_sound
        anda #$f7
        sta $ff23
        lda $ff03
        anda #$f7
        ldb <input_mode
        cmpb #2
        bne joystick_right
        ora #8
joystick_right
        sta $ff03
        lda $ff01
        anda #$f7
        sta $ff01
        lda #96
        sta $ff20
        nop
joystick_x_low
        lda $ff00
        bmi joystick_x_high_test
        lda <input_bits
        ora #4
        sta <input_bits
        bra joystick_y_test
joystick_x_high_test
        lda #160
        sta $ff20
        nop
joystick_x_high
        lda $ff00
        bpl joystick_y_test
        lda <input_bits
        ora #8
        sta <input_bits
joystick_y_test
        lda $ff01
        ora #8
        sta $ff01
        lda #96
        sta $ff20
        nop
joystick_y_low
        lda $ff00
        bmi joystick_y_high_test
        lda <input_bits
        ora #1
        sta <input_bits
        bra joystick_buttons
joystick_y_high_test
        lda #160
        sta $ff20
        nop
joystick_y_high
        lda $ff00
        bpl joystick_buttons
        lda <input_bits
        ora #2
        sta <input_bits
joystick_buttons
        lda $ff00
        coma
        ldb <input_mode
        cmpb #2
        beq joystick_left_fire
        anda #5
        bra joystick_fire_test
joystick_left_fire
        anda #10
joystick_fire_test
        beq joystick_restore
        lda <input_bits
        ora #$10
        sta <input_bits
joystick_restore
        lda $ff01
        anda #$f7
        sta $ff01
        lda $ff03
        anda #$f7
        sta $ff03
        lda <saved_dac
        sta $ff20
        lda <saved_sound
        sta $ff23
        puls cc,pc

key_definitions
        ; column, row bit, input mask: arrows, WASD, space, pause, restart.
        fcb 3,8,1,4,8,2,5,8,4,6,8,8
        fcb 7,4,1,3,4,2,1,1,4,4,1,8
        fcb 7,8,$10,0,4,$20,2,4,$40,$ff

; Map a physical raster line (0..447) and byte-column into the $8000 window.
framebuffer_pointer
        lda <span_row+1
        lsra
        lsra
        lsra
        lsra
        lsra
        lsra
        tst <span_row
        beq framebuffer_bank_ready
        adda #4
framebuffer_bank_ready
        sta <row_bank
        sta $ffa4
        lda <span_row+1
        lsra
        anda #$1f
        ora #$80
        ldb <span_x
        bcc framebuffer_even
        orb #$80
framebuffer_even
        tfr d,u
        rts

; X=source. A single physical copy; mirrored background rows are explicit.
write_span
        jsr framebuffer_pointer
        ldb <span_n
        cmpb #128
        beq write_full_scanline
write_span_loop
        lda ,x+
        sta ,u+
        decb
        bne write_span_loop
        rts
write_full_scanline
        lda #8
        sta <span_blocks
write_full_block
        ldd ,x
        std ,u
        ldd 2,x
        std 2,u
        ldd 4,x
        std 4,u
        ldd 6,x
        std 6,u
        ldd 8,x
        std 8,u
        ldd 10,x
        std 10,u
        ldd 12,x
        std 12,u
        ldd 14,x
        std 14,u
        leax 16,x
        leau 16,u
        dec <span_blocks
        bne write_full_block
        rts

render_world_line
        lda #7
        sta $ffa6
        ldd <world_line
        lslb
        rola
        lslb
        rola
        andb #$e0
        addd #$c000
        tfr d,x
        ldu #TILE_ROW
        ldb #32
copy_map_row
        lda ,x+
        sta ,u+
        decb
        bne copy_map_row
        lda #$0d
        sta $ffa6
        lda <world_line+1
        anda #7
        lsla
        lsla
        sta <tile_line
        lda #32
        sta <tiles_left
        ldx #TILE_ROW
        ldy #SCANLINE
render_tile_line
        lda ,x+
        ldb #32
        mul
        addd #$a000
        addb <tile_line
        adca #0
        tfr d,u
        ldd ,u++
        std ,y++
        ldd ,u
        std ,y++
        dec <tiles_left
        bne render_tile_line
        clr <span_x
        clr <span_row
        lda <target_line
        sta <span_row+1
        lda #128
        sta <span_n
        ldx #SCANLINE
        jsr write_span
        lda <target_line
        cmpa #192
        bhs no_mirror_line
        lda #1
        sta <span_row
        ldx #SCANLINE
        jsr write_span
no_mirror_line
        rts

draw_hud
        clra
        ldb <ring_head
        addd #VIEW_HEIGHT
        std <span_row
        clr <span_x
        lda #128
        sta <span_n
        lda #16
        sta <object_lines
        ldx #$d000
hud_row_loop
        jsr write_span
        ldd <span_row
        addd #1
        std <span_row
        dec <object_lines
        bne hud_row_loop
        rts

erase_player
        tst <sprite_valid
        beq erase_return
        ldd <sprite_screen_row
        std <span_row
        lda <sprite_xbyte
        sta <span_x
        lda #9
        sta <span_n
        lda #16
        sta <object_lines
        ldx #SAVED_PLAYER
erase_row_loop
        jsr write_span
        ldd <span_row
        addd #1
        std <span_row
        dec <object_lines
        bne erase_row_loop
erase_return
        rts

draw_player
        clra
        ldb <ring_head
        addb <player_y
        adca #0
        std <sprite_screen_row
        std <span_row
        lda <player_x
        lsra
        sta <sprite_xbyte
        sta <span_x
        ldb <player_frame
        lslb
        lda <player_x
        anda #1
        stb <tiles_left
        adda <tiles_left
        lsla
        ldx #player_pointers
        ldx a,x
        stx <sprite_pointer
        ldy #SAVED_PLAYER
        lda #16
        sta <object_lines
        lda #9
        sta <span_n
draw_player_row
        jsr framebuffer_pointer
        ldx <sprite_pointer
        clrb
draw_player_byte
        lda ,u+
        sta ,y+
        anda ,x+
        ora ,x+
        sta 143,y
        incb
        cmpb #9
        blo draw_player_byte
        stx <sprite_pointer
        leax 135,y
        jsr write_span
        ldd <span_row
        addd #1
        std <span_row
        dec <object_lines
        bne draw_player_row
        lda #1
        sta <sprite_valid
        rts

player_pointers
        fdb $c000,$c120,$c240,$c360

publish_head
        clra
        ldb <ring_head
        lslb
        rola
        lslb
        rola
        lslb
        rola
        lslb
        rola
        addd #$c000
        std $ff9d
frame_complete
        rts
