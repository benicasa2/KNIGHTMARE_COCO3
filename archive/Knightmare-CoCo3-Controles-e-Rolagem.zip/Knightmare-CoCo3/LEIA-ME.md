# Knightmare CoCo 3 — controles e rolagem

Esta versão acrescenta movimento de Popolon por teclado e joystick, animação original e rolagem automática do mapa inteiro da primeira fase. As duas variantes continuam usando Assembly 6809 e 128 KiB: DAC interno de 6 bits e Orchestra-90 CC de 8 bits.

**É uma demonstração interativa. Ainda não é o jogo completo:** faltam disparos/projéteis, inimigos ativos, colisões, itens, chefes com lógica, progressão de fases e o sequenciador original de áudio. Os valores do HUD são estáticos; a música continua sendo o trecho capturado da etapa anterior.

## Executar

No Windows deste usuário, `EXECUTAR-DAC6.cmd` e `EXECUTAR-ORCH90.cmd` procuram a instalação existente do XRoar. Aguarde o carregamento do disco. Se o emulador estiver em outra pasta:

```powershell
python tools/run_demo.py --variant DAC6 --xroar C:\caminho\xroar.exe
python tools/run_demo.py --variant ORCH90 --xroar C:\caminho\xroar.exe
```

Também é possível montar `bin/DAC6.DSK` ou `bin/ORCH90.DSK` no drive 0 e digitar `RUN"START"`. Para o script, as ROMs de sistema do usuário `coco3.rom` e `disk11.rom` devem estar ao lado do XRoar. A variante Orchestra configura Multi-Pak com Orchestra-90 no slot 0 e controlador de disco no slot 3. Em hardware real, use a saída RGB; a variante Orchestra requer o cartucho e sua conexão de áudio.

## Controles

| Tecla/dispositivo | Ação |
| --- | --- |
| Setas ou W/A/S/D | Mover Popolon; diagonais permitidas |
| K | Somente teclado, modo inicial |
| J | Ativar joystick analógico direito; teclado continua ativo |
| L | Ativar joystick analógico esquerdo; teclado continua ativo |
| P | Pausar/retomar movimento e rolagem |
| R | Reiniciar a travessia do mapa |
| Espaço/botões do joystick | Entrada lida; projéteis ainda não implementados |

A rolagem acontece automaticamente até o topo do mapa, onde para. O jogador permanece dentro do campo de jogo e o HUD fica fixo. Se não houver joystick conectado, use K. A configuração de um controle USB no computador é feita pelo menu de joysticks do XRoar; esta versão lê as portas analógicas emuladas do CoCo.

## Arquivos principais

- `src/hardware_probe.asm`: inicialização e áudio comum às duas variantes.
- `src/gameplay.asm`: teclado, joystick, movimento, sprites e rolagem.
- `src/game_state.inc`: estado de execução.
- `analysis/CONTROLES-E-ROLAGEM.md`: implementação, memória e limites desta etapa.
- `analysis/*-controls-verification.json`: resultados dos testes dos binários atuais.
- `analysis/*-interactive-*.png`: imagens lidas do framebuffer real do XRoar.
- `analysis/RELATORIO.md`: histórico da análise da ROM com REA/Ghidra.
- `assets/stages/`: mapas e tiles extraídos das oito fases; somente a primeira está integrada nesta versão.
- `reference/MSX-reference.wav`: referência de áudio do openMSX, não uma gravação do CoCo.

## Compilar e testar

Requer Python 3, LWASM e XRoar existentes; não requer pacotes Python adicionais.

```powershell
python tools/build.py --lwasm C:\caminho\lwasm.exe
python tools/verify_controls_scroll.py --xroar C:\caminho\xroar.exe
```

O teste percorre 1.776 pixels de rolagem nas duas compilações, verifica várias voltas do buffer, compara o framebuffer com um renderizador independente e testa limites, diagonais, pausa, reinício e áudio ativo. Os sinais externos de teclado e comparador são simulados nas fronteiras de leitura das PIAs, com o código 6809 real executando o decodificador e os controles. Não foi feito teste com joystick físico. A tentativa de enviar uma tecla pela janela do Windows não pôde ser concluída; não é apresentada como teste aprovado.

## Análise e recursos originais

A ROM usada continua identificada pelo SHA-256 `589b2fd276d84827bb1b033f43a0cd5ab0aa9da3c8784cac2f62474fed00aae3`. O arquivo original foi preservado.

As ferramentas de extração em `third_party/knightmare/` vêm de [antxiko/Knightmare-disassembly](https://github.com/antxiko/Knightmare-disassembly), com autoria e licença preservadas, e foram aplicadas à ROM fornecida. O script de sementes do [REA-RETRO-9](https://github.com/benicasa2/REA-RETRO-9) está em `third_party/rea/` com licença e origem.

```powershell
python tools/prepare_player.py --rom C:\caminho\Knightmare.rom
python tools/export_resources.py --rom C:\caminho\Knightmare.rom
python tools/analyze_rom.py --rom C:\caminho\Knightmare.rom --ghidra C:\caminho\ghidra_12.1.4_PUBLIC --java C:\caminho\jdk\bin\java.exe
```

O exportador headless usa o script de sementes do REA. A evidência `analysis/rea-audio-tick.json` foi obtida pela CLI completa do REA na etapa anterior. A reconstrução gráfica da primeira fase foi conferida contra 12.288 bytes da VRAM do openMSX, sem diferenças.
