        org $0b00
        jsr $55c5
        sta $0be4

harness_done
        bra harness_done
