"""Real XRoar/6809 execution: Disk BASIC boot, framebuffer and timed DAC probes."""
from pathlib import Path
import argparse,subprocess,socket,time,re,json,hashlib,struct
ROOT=Path(__file__).resolve().parents[1]
class RSP:
 def __init__(self,port):
  self.s=socket.create_connection(('127.0.0.1',port),timeout=20);self.s.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
 def cmd(self,cmd):
  b=cmd.encode();self.s.sendall(b'$'+b+b'#'+f'{sum(b)&255:02x}'.encode())
  return self.recv()
 def recv(self):
  while True:
   c=self.s.recv(1)
   if c==b'$':break
   if not c:raise EOFError
  out=bytearray()
  while (c:=self.s.recv(1))!=b'#':
   if not c:raise EOFError
   out+=c
  chk=self.s.recv(2);assert int(chk,16)==sum(out)%256
  self.s.sendall(b'+');return out.decode()
 def read(self,a,n):return b''.join(bytes.fromhex(self.cmd(f'm{a+p:x},{min(512,n-p):x}')) for p in range(0,n,512))
 def write(self,a,b):assert self.cmd(f'M{a:x},{len(b):x}:'+b.hex())=='OK'
 def bp(self,a):assert self.cmd(f'Z0,{a:x},1')=='OK'
 def unbp(self,a):assert self.cmd(f'z0,{a:x},1')=='OK'
 def go(self):assert self.cmd('c')=='S05'
 def step(self):assert self.cmd('s')=='S05'
def symbols(name):
 return {m[1]:int(m[2],16) for m in re.finditer(r'(?m)^(\w+) EQU \$([0-9a-fA-F]+)',(ROOT/f'analysis/{name}.sym').read_text())}
def verify(exe,name):
 sy=symbols(name)
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 log=(ROOT/f'analysis/{name}-xroar.log').open('wb')
 args=[str(exe),'-machine','coco3','-ram','128','-no-bas','-extbas',str(exe.parent/'coco3.rom'),'-cart','rsdos','-cart-rom',str(exe.parent/'disk11.rom'),'-load-fd0',str(ROOT/f'bin/{name}.DSK'),'-type','RUN"START"\r','-no-ratelimit','-tv-input','rgb','-ui','null','-ao','null','-gdb','-gdb-port',str(port),'-no-disk-write-back']
 if name=='ORCH90':
  ix=args.index('-load-fd0');args[ix:ix]=['-cart','mpi','-mpi-slot','3','-mpi-load-cart','0=orch90','-mpi-load-cart','3=rsdos']
 p=subprocess.Popen(args,stdout=log,stderr=log);r=None
 try:
  for _ in range(60):
   try:r=RSP(port);break
   except OSError:
    if p.poll() is not None:raise RuntimeError('XRoar exited')
    time.sleep(.1)
  assert r
  # XRoar may already have executed the loader before the debugger connects.
  if r.read(sy['start'],2)!=bytes.fromhex('1a50'):
   r.bp(sy['start']);r.go();r.unbp(sy['start'])
  assert r.cmd(f'P8={sy["start"]:04x}')=='OK'
  r.bp(sy['main_loop']);r.go();r.unbp(sy['main_loop'])
  packed=bytearray()
  for bank in range(3):
   r.write(0xffa4,bytes([bank]));packed+=r.read(0x8000,8192)
  r.write(0xffa4,b'\x3c')
  assert packed==(ROOT/'assets/scene.4bpp').read_bytes(),'Framebuffer differs from reference'
  palette=[b&63 for b in r.read(0xffb0,16)]
  assert palette==json.loads((ROOT/'analysis/build.json').read_text())['palette']
  import sys
  sys.path.insert(0,str(ROOT/'tools'));from render_msx import png
  pixels=bytearray()
  for b in packed:pixels+=bytes([b>>4,b&15])
  rgb=[((((v>>5)&1)*2+((v>>2)&1))*85,(((v>>4)&1)*2+((v>>1)&1))*85,(((v>>3)&1)*2+(v&1))*85) for v in palette]
  png(ROOT/f'analysis/{name}-actual-xroar.png',pixels,palette=rgb)
  r.bp(sy['next_frame'])
  trace=(ROOT/'assets/audio-trace.bin').read_bytes()
  first_audible=next(i//17 for i in range(0,len(trace),17) if any(trace[i+8:i+11]))
  # Observe timed frame progression up to the first non-silent captured event.
  for _ in range(first_audible+2):r.go();r.step()
  r.unbp(sy['next_frame'])
  dac_address=0xff7b if name=='ORCH90' else 0xff20
  assert r.cmd(f'Z2,{dac_address:x},1')=='OK'
  samples=[]
  for _ in range(256):
   r.go();samples.append(bytes.fromhex(r.cmd('g'))[1]);r.step()
  assert r.cmd(f'z2,{dac_address:x},1')=='OK'
  played=int.from_bytes(r.read(sy['frames_played'],2),'big')
  assert played>=first_audible+1
  if len(set(samples))<=1:
   diag=dict(registers=r.cmd('g'),state=r.read(sy['state_begin'],sy['state_end']-sy['state_begin']).hex(),frames=played,samples=samples[:16])
   (ROOT/f'analysis/{name}-audio-diagnostic.json').write_text(json.dumps(diag,indent=2))
  assert len(set(samples))>1,'Audio is constant'
  rewind=sy['trace_valid']-3
  assert r.read(rewind,1)==b'\x8e'
  r.bp(rewind);r.go();r.unbp(rewind)
  played=int.from_bytes(r.read(sy['frames_played'],2),'big')
  assert played>=len(trace)//17
  result=dict(variant=name,emulator='XRoar 1.12',machine='coco3',ram_kib=128,disk_basic_boot=True,framebuffer_matches=True,framebuffer_sha256=hashlib.sha256(packed).hexdigest(),palette=palette,frames_played=played,trace_wrap_reached=True,dac_write_watchpoint=f'0x{dac_address:04x}',dac_probe_samples=len(samples),dac_probe_unique_values=sorted(set(samples)),orchestra_cartridge_configured=name=='ORCH90',status='hardware probe verified; no gameplay claim')
  (ROOT/f'analysis/{name}-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
  return result
 finally:
  if r:r.s.close()
  p.terminate();p.wait(timeout=10);log.close()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--xroar',type=Path,required=True);ap.add_argument('--variant',choices=['DAC6','ORCH90']);args=ap.parse_args()
 for name in ([args.variant] if args.variant else ['DAC6','ORCH90']):print(json.dumps(verify(args.xroar,name),indent=2))
if __name__=='__main__':main()
