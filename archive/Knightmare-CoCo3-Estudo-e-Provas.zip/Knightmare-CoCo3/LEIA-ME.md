# Knightmare para CoCo 3 — engenharia reversa e provas técnicas

**Estado: conversão incompleta. Os discos deste pacote NÃO são versões jogáveis de Knightmare.**

O pedido de uma recriação completa, fiel ao original e com os dois sistemas de áudio ainda não foi cumprido. Este pacote contém o trabalho efetivamente realizado: análise da ROM fornecida com REA/Ghidra, extração de recursos, referências de execução no openMSX e duas provas de vídeo/áudio em Assembly 6809 para CoCo 3 com 128 KiB.

## O que executar

| Arquivo | Conteúdo |
| --- | --- |
| `bin/DAC6.DSK` | Cena estática e trecho de áudio sintetizado no DAC interno de 6 bits |
| `bin/ORCH90.DSK` | A mesma prova com saída de 8 bits em ambos os canais do Orchestra-90 CC |
| `src/hardware_probe.asm` | Código nativo 6809 das duas provas |
| `analysis/RELATORIO.md` | Evidências, arquitetura, limites e trabalho que falta |
| `reference/MSX-reference.wav` | Referência de áudio gravada no openMSX; não é áudio do CoCo |
| `assets/stages/` | Mapas gráficos extraídos das oito fases; não incluem a execução dos inimigos |
| `assets/sprites/` | Jogador, armas, inimigos e alguns chefes extraídos da ROM |
| `analysis/listing-z80.tsv` | Instruções reconhecidas pelo Ghidra |
| `analysis/rea-audio-tick.json` | Evidência do REA para a rotina original de áudio |

Monte o disco desejado no drive 0 e digite `RUN"START"`. A prova exibe uma cena estática e repete aproximadamente dez segundos de áudio. Ela não possui controles, movimento, colisão ou progressão de fases. Para sair, reinicie o emulador/computador. No CoCo real, use monitor RGB e, na variante ORCH90, o cartucho com sua saída ligada ao amplificador.

O teste de ORCH90 no XRoar usa Multi-Pak, Orchestra-90 no slot 0 e controlador de disco no slot 3. A saída dos dois canais contém a mesma mistura mono; não foi inventada uma separação estéreo para a trilha original.

## Compilar e verificar

Requer Python 3, LWASM e XRoar com as ROMs de sistema fornecidas pelo usuário. Não requer pacotes Python adicionais.

```powershell
python tools/build.py --lwasm C:\caminho\lwasm.exe
python tools/verify_probe.py --xroar C:\caminho\xroar.exe
```

As ROMs `coco3.rom` e `disk11.rom` devem estar ao lado do XRoar para esse script. O verificador inicia uma instância própria, executa o carregador Disk BASIC com 128 KiB, compara o framebuffer, observa a progressão do timer e usa watchpoints nas escritas DAC. Encerra somente a instância criada por ele. Os relatórios são gravados em `analysis/`.

Para refazer a análise estática com uma distribuição Ghidra e JDK existentes:

```powershell
python tools/analyze_rom.py --rom C:\caminho\Knightmare.rom --ghidra C:\caminho\ghidra_12.1.4_PUBLIC --java C:\caminho\jdk\bin\java.exe
```

Esse comando usa o script de sementes do REA incluído com licença. A evidência `rea-audio-tick.json` foi obtida pela CLI completa do REA; não é produzida por esse exportador headless.

As imagens em `analysis/*-actual-xroar.png` vêm do framebuffer e da paleta lidos no emulador, não de um mockup. A resolução é 256×192 com 16 índices de cor; os valores RGB são aproximações na paleta de 64 cores do GIME.

## Reproduzir a extração das fases

As ferramentas de extração de fases, telas e sprites em `third_party/knightmare/` são do projeto [antxiko/Knightmare-disassembly](https://github.com/antxiko/Knightmare-disassembly), com licença e autoria preservadas. Foram executadas sobre **a ROM fornecida pelo usuário**, cujo hash é diferente da revisão usada pelo autor desse projeto.

```powershell
python third_party/knightmare/mapas.py C:\caminho\Knightmare.rom 0x4000 assets/stages
python third_party/knightmare/pantallas.py C:\caminho\Knightmare.rom 0x4000 assets/screens
python third_party/knightmare/sprites.py C:\caminho\Knightmare.rom 0x4000 assets/sprites
python tools/export_resources.py --rom C:\caminho\Knightmare.rom
```

A reconstrução das tabelas gráficas da primeira fase foi confrontada com a VRAM do openMSX e teve zero diferenças em 12.288 bytes. As outras fases foram extraídas, mas não passaram por esse confronto independente nesta execução.

`tools/capture_msx.tcl` registra novamente as referências quando executado a partir da raiz deste pacote, por exemplo `openmsx -machine C-BIOS_MSX1 -cart C:\caminho\Knightmare.rom -script tools/capture_msx.tcl`. A gravação controla as teclas dessa instância do emulador e termina após 30 segundos emulados. Os relatórios do pacote correspondem à ROM identificada pelo SHA-256 documentado.

## O que ainda falta

Reescrever e testar a máquina de estados, controles, rolagem, renderização de sprites em software, armas, inimigos, objetos, colisões, chefes, pontuação, vidas, todas as fases e o final. O áudio atual reproduz um registro temporal fixo: falta converter o sequenciador original e suas prioridades para que músicas e efeitos respondam à partida. Nenhuma campanha completa foi testada e nenhum teste foi realizado em CoCo físico.

O código 6809 e os relatórios novos deste pacote não substituem o trabalho restante. As rotinas Z80 decompiladas automaticamente não são código 6809 compilável.
